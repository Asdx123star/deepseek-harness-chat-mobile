package com.example.dshchat

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.method.LinkMovementMethod
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import io.noties.markwon.Markwon
import java.util.WeakHashMap

class ChatAdapter(
    private val items: MutableList<ChatMessage>,
    private val appearance: () -> AppearanceState
) : RecyclerView.Adapter<ChatAdapter.Holder>() {

    class Holder(
        val row: LinearLayout,
        val bubble: LinearLayout,
        val reasoning: TextView,
        val text: TextView
    ) : RecyclerView.ViewHolder(row)

    private val markwonCache = WeakHashMap<Context, Markwon>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val context = parent.context
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 12), dp(context, 5), dp(context, 12), dp(context, 5))
            layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val bubble = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 14), dp(context, 11), dp(context, 14), dp(context, 12))
            elevation = dp(context, 1).toFloat()
        }
        val reasoning = TextView(context).apply {
            includeFontPadding = false
            setLineSpacing(dp(context, 2).toFloat(), 1.18f)
            visibility = View.GONE
            setPadding(dp(context, 2), dp(context, 1), dp(context, 2), dp(context, 7))
        }
        val text = TextView(context).apply {
            includeFontPadding = false
            setLineSpacing(dp(context, 3).toFloat(), 1.22f)
            movementMethod = LinkMovementMethod.getInstance()
            setTextIsSelectable(true)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        bubble.addView(reasoning)
        bubble.addView(text)
        row.addView(bubble)
        return Holder(row, bubble, reasoning, text)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        val context = holder.row.context
        val a = appearance()
        val params = holder.bubble.layoutParams as LinearLayout.LayoutParams
        val fontScale = a.fontScale.coerceIn(0.9f, 1.3f)

        holder.text.textSize = 16.5f * fontScale
        holder.reasoning.textSize = 13.0f * fontScale

        if (item.role == ChatRole.USER) {
            holder.row.gravity = Gravity.END
            params.width = ViewGroup.LayoutParams.WRAP_CONTENT
            params.weight = 0f
            holder.bubble.background = rounded(context, if (a.dark) Color.rgb(49, 88, 137) else Color.rgb(220, 235, 255), 18,
                if (a.dark) Color.rgb(78, 115, 163) else Color.rgb(188, 211, 242))
            holder.text.setTextColor(if (a.dark) Color.WHITE else Color.rgb(24, 48, 79))
        } else {
            holder.row.gravity = Gravity.START
            params.width = ViewGroup.LayoutParams.MATCH_PARENT
            params.weight = 0f
            val bg = when {
                a.dark && a.highContrast -> Color.argb(246, 20, 36, 58)
                a.dark -> Color.argb(220, 20, 36, 58)
                a.highContrast -> Color.argb(248, 255, 255, 255)
                else -> Color.argb(226, 255, 255, 255)
            }
            val stroke = if (a.dark) Color.argb(115, 135, 162, 194) else Color.argb(100, 167, 189, 215)
            holder.bubble.background = rounded(context, bg, 18, stroke)
            holder.text.setTextColor(if (a.dark) Color.rgb(239, 245, 252) else Color.rgb(25, 39, 56))
        }
        holder.bubble.layoutParams = params

        val visibleText = when {
            item.streaming && item.text.isEmpty() -> "▍"
            item.streaming -> item.text + " ▍"
            else -> item.text
        }
        if (item.role == ChatRole.ASSISTANT && visibleText.isNotBlank()) {
            val markwon = markwonCache.getOrPut(context) { Markwon.create(context) }
            markwon.setMarkdown(holder.text, visibleText)
        } else {
            holder.text.text = visibleText
        }

        if (item.role == ChatRole.ASSISTANT && item.reasoning.isNotBlank()) {
            holder.reasoning.visibility = View.VISIBLE
            holder.reasoning.setTextColor(if (a.dark) Color.rgb(166, 187, 211) else Color.rgb(91, 111, 135))
            holder.reasoning.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            if (item.reasoningExpanded) {
                holder.reasoning.text = "思考  ▲\n${item.reasoning}\n"
            } else {
                val preview = item.reasoning.replace('\n', ' ').trim().take(72)
                holder.reasoning.text = "思考  ▼  $preview${if (item.reasoning.length > 72) "…" else ""}\n"
            }
            holder.reasoning.setOnClickListener {
                item.reasoningExpanded = !item.reasoningExpanded
                val p = holder.bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION) notifyItemChanged(p)
            }
        } else {
            holder.reasoning.visibility = View.GONE
            holder.reasoning.setOnClickListener(null)
        }
    }

    override fun getItemCount(): Int = items.size

    companion object {
        private fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
        private fun rounded(context: Context, color: Int, radius: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(context, radius).toFloat()
            if (stroke != null) setStroke(dp(context, 1), stroke)
        }
    }
}
