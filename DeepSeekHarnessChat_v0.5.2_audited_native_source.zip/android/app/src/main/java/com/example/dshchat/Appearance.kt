package com.example.dshchat

data class AppearanceState(
    val skin: String,
    val fontScale: Float,
    val highContrast: Boolean,
    val dark: Boolean
)
