import http from 'node:http'
import fs from 'node:fs'
import fsp from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { syncBuiltinESMExports } from 'node:module'

// Android app sandboxes on some ROM/filesystems reject hard-link publication with
// EACCES/EPERM. Harness persistence uses link() as a no-clobber atomic publish.
// Preserve EEXIST semantics and fall back to same-filesystem rename only when the
// platform rejects hard links. This is the same compatibility seam proven in the
// earlier Termux build.
const originalLink = fs.promises.link.bind(fs.promises)
const originalRename = fs.promises.rename.bind(fs.promises)
const originalLstat = fs.promises.lstat.bind(fs.promises)
fs.promises.link = async function androidLinkFallback(oldPath, newPath) {
  try {
    return await originalLink(oldPath, newPath)
  } catch (error) {
    if (!error || !['EACCES', 'EPERM'].includes(error.code)) throw error
    try {
      await originalLstat(newPath)
      const exists = new Error(`EEXIST: file already exists, link '${oldPath}' -> '${newPath}'`)
      Object.assign(exists, { code: 'EEXIST', errno: -17, syscall: 'link', path: oldPath, dest: newPath })
      throw exists
    } catch (checkError) {
      if (!checkError || checkError.code !== 'ENOENT') throw checkError
    }
    return await originalRename(oldPath, newPath)
  }
}
syncBuiltinESMExports()

const here = path.dirname(fileURLToPath(import.meta.url))
const appFiles = process.argv[2] || process.cwd()
const dshHome = path.join(appFiles, 'dsh-home')
const workspace = path.join(appFiles, 'workspace')
const tmpDir = path.join(appFiles, 'tmp')

fs.mkdirSync(dshHome, { recursive: true })
fs.mkdirSync(workspace, { recursive: true })
fs.mkdirSync(tmpDir, { recursive: true })
fs.mkdirSync(path.join(dshHome, '.agent-presets', 'mobile-chat'), { recursive: true })

for (const [src, dest] of [
  [path.join(here, 'bootstrap', 'cordis.patch.yml'), path.join(dshHome, 'cordis.patch.yml')],
  [path.join(here, 'bootstrap', 'mobile-chat', 'preset.yml'), path.join(dshHome, '.agent-presets', 'mobile-chat', 'preset.yml')],
  [path.join(here, 'bootstrap', 'mobile-chat', 'agent.cordis.yml'), path.join(dshHome, '.agent-presets', 'mobile-chat', 'agent.cordis.yml')],
]) {
  fs.copyFileSync(src, dest)
}

process.env.HOME = appFiles
process.env.DSH_HOME = dshHome
process.env.DSH_CWD = workspace
process.env.DSH_TELEMETRY_DISABLED = '1'
process.env.TMPDIR = tmpDir
process.env.TMP = tmpDir
process.env.TEMP = tmpDir
process.chdir(workspace)

// ── In-process sampling proxy (same contract the v0.4 Termux helper exposed). ──
const PROXY_HOST = '127.0.0.1'
const PROXY_PORT = 37129
const proxyConfigPath = path.join(dshHome, 'mobile-proxy.json')
const defaultProxy = { upstreamBaseURL: 'https://api.deepseek.com', temperature: null, topP: null }

function validateConfig(input) {
  const out = { ...defaultProxy }
  const upstream = String(input?.upstreamBaseURL || defaultProxy.upstreamBaseURL).trim().replace(/\/+$/, '')
  const u = new URL(upstream)
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('upstreamBaseURL 只支持 http/https')
  out.upstreamBaseURL = upstream
  if (input?.temperature !== null && input?.temperature !== undefined) {
    const n = Number(input.temperature)
    if (!Number.isFinite(n) || n < 0 || n > 2) throw new Error('temperature 必须在 0~2')
    out.temperature = Math.round(n * 100) / 100
  }
  if (input?.topP !== null && input?.topP !== undefined) {
    const n = Number(input.topP)
    if (!Number.isFinite(n) || n < 0 || n > 1) throw new Error('top_p 必须在 0~1')
    out.topP = Math.round(n * 100) / 100
  }
  return out
}
async function readConfig() {
  try { return validateConfig({ ...defaultProxy, ...JSON.parse(await fsp.readFile(proxyConfigPath, 'utf8')) }) }
  catch { return { ...defaultProxy } }
}
async function writeConfig(cfg) {
  await fsp.writeFile(proxyConfigPath, JSON.stringify(cfg, null, 2) + '\n', { mode: 0o600 })
}
async function readBody(req) {
  const chunks = []
  for await (const c of req) chunks.push(Buffer.from(c))
  return Buffer.concat(chunks)
}
function sendJson(res, code, value) {
  const body = Buffer.from(JSON.stringify(value))
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'content-length': String(body.length), 'cache-control': 'no-store' })
  res.end(body)
}
const proxy = http.createServer(async (req, res) => {
  try {
    if (req.url === '/__dsh_mobile/config') {
      if (req.method === 'GET') return sendJson(res, 200, await readConfig())
      if (req.method === 'POST') {
        let patch
        try { patch = JSON.parse((await readBody(req)).toString('utf8') || '{}') }
        catch { return sendJson(res, 400, { error: 'JSON 无法解析' }) }
        const next = validateConfig({ ...(await readConfig()), ...patch })
        await writeConfig(next)
        return sendJson(res, 200, next)
      }
      return sendJson(res, 405, { error: 'method not allowed' })
    }

    const cfg = await readConfig()
    const incoming = new URL(req.url || '/', 'http://localhost')
    const upstream = new URL(cfg.upstreamBaseURL.replace(/\/+$/, '') + incoming.pathname + incoming.search)
    const headers = { ...req.headers }
    delete headers.host; delete headers.connection; delete headers['content-length']; delete headers['transfer-encoding']
    let body = ['GET', 'HEAD'].includes(req.method || 'GET') ? undefined : await readBody(req)
    if (body?.length && incoming.pathname.endsWith('/chat/completions') && String(req.headers['content-type'] || '').includes('application/json')) {
      try {
        const json = JSON.parse(body.toString('utf8'))
        if (json?.thinking?.type === 'disabled') {
          if (cfg.temperature !== null) json.temperature = cfg.temperature
          if (cfg.topP !== null) json.top_p = cfg.topP
        }
        body = Buffer.from(JSON.stringify(json))
      } catch {}
    }
    const abort = new AbortController()
    req.on('aborted', () => abort.abort())
    res.on('close', () => { if (!res.writableEnded) abort.abort() })
    const answer = await fetch(upstream, { method: req.method, headers, body, signal: abort.signal, redirect: 'manual' })
    const responseHeaders = {}
    answer.headers.forEach((value, key) => {
      if (!['content-length', 'transfer-encoding', 'content-encoding', 'connection'].includes(key.toLowerCase())) responseHeaders[key] = value
    })
    responseHeaders['x-dsh-mobile-proxy'] = 'v0.5.2-embedded'
    res.writeHead(answer.status, responseHeaders)
    if (answer.body) for await (const chunk of answer.body) res.write(Buffer.from(chunk))
    res.end()
  } catch (e) {
    if (!res.headersSent) sendJson(res, 502, { error: String(e?.message || e) })
    else res.destroy(e instanceof Error ? e : undefined)
  }
})
proxy.listen(PROXY_PORT, PROXY_HOST, () => console.log(`dsh embedded sampling proxy: http://${PROXY_HOST}:${PROXY_PORT}`))

// Start the official @deepseek-ai/dsh Web/API composition on loopback.
const dshBin = path.join(here, 'node_modules', '@deepseek-ai', 'dsh', 'lib', 'bin.js')
if (!fs.existsSync(dshBin)) throw new Error(`@deepseek-ai/dsh missing from embedded assets: ${dshBin}`)
process.argv = ['node', dshBin, 'web', '--host', '127.0.0.1', '--port', '37128']
await import(pathToFileURL(dshBin).href)
