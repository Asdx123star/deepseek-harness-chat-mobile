#include <jni.h>
#include <node.h>
#include <android/log.h>
#include <unistd.h>
#include <pthread.h>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

namespace {
constexpr const char* TAG = "DSH-EMBEDDED";
int pipe_stdout[2] = {-1, -1};
int pipe_stderr[2] = {-1, -1};
pthread_t stdout_thread{};
pthread_t stderr_thread{};

void* log_pipe(void* raw) {
    int fd = *static_cast<int*>(raw);
    char buf[4096];
    while (true) {
        const ssize_t n = read(fd, buf, sizeof(buf) - 1);
        if (n <= 0) break;
        size_t used = static_cast<size_t>(n);
        if (used > 0 && buf[used - 1] == '\n') --used;
        buf[used] = '\0';
        __android_log_write(fd == pipe_stderr[0] ? ANDROID_LOG_ERROR : ANDROID_LOG_INFO, TAG, buf);
    }
    return nullptr;
}

void start_logging() {
    setvbuf(stdout, nullptr, _IONBF, 0);
    setvbuf(stderr, nullptr, _IONBF, 0);
    if (pipe(pipe_stdout) == 0) {
        dup2(pipe_stdout[1], STDOUT_FILENO);
        pthread_create(&stdout_thread, nullptr, log_pipe, &pipe_stdout[0]);
        pthread_detach(stdout_thread);
    }
    if (pipe(pipe_stderr) == 0) {
        dup2(pipe_stderr[1], STDERR_FILENO);
        pthread_create(&stderr_thread, nullptr, log_pipe, &pipe_stderr[0]);
        pthread_detach(stderr_thread);
    }
}
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_dshchat_EmbeddedHarnessRuntime_startNodeWithArguments(
        JNIEnv* env, jobject /* thiz */, jobjectArray arguments) {
    const jsize argc = env->GetArrayLength(arguments);
    std::vector<std::string> strings;
    strings.reserve(static_cast<size_t>(argc));
    size_t total = 0;
    for (jsize i = 0; i < argc; ++i) {
        auto value = static_cast<jstring>(env->GetObjectArrayElement(arguments, i));
        const char* utf = env->GetStringUTFChars(value, nullptr);
        strings.emplace_back(utf);
        total += strings.back().size() + 1;
        env->ReleaseStringUTFChars(value, utf);
        env->DeleteLocalRef(value);
    }

    // libuv's argv normalization expects writable contiguous argument storage.
    std::vector<char> buffer(total);
    // C/C++ argv convention requires argv[argc] == nullptr. Node/libuv may
    // inspect that sentinel during argument normalization.
    std::vector<char*> argv(static_cast<size_t>(argc) + 1, nullptr);
    char* cursor = buffer.data();
    for (jsize i = 0; i < argc; ++i) {
        const auto& value = strings[static_cast<size_t>(i)];
        std::memcpy(cursor, value.c_str(), value.size() + 1);
        argv[static_cast<size_t>(i)] = cursor;
        cursor += value.size() + 1;
    }

    start_logging();
    __android_log_write(ANDROID_LOG_INFO, TAG, "Starting embedded Node.js / DeepSeek Harness");
    return static_cast<jint>(node::Start(static_cast<int>(argc), argv.data()));
}
