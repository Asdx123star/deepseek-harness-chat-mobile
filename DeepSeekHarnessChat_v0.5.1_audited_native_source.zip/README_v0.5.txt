DeepSeek Harness Chat v0.5.1 — Embedded Harness experimental build
==================================================================

目标
----
v0.5 的核心目标是：在 Android APK 内嵌 Node.js + 官方 @deepseek-ai/dsh，打开 App 后自动启动
127.0.0.1:3080，不再要求用户日常打开 Termux 并手动运行 dsh web。

为什么标记“实验版”
------------------
官方 DeepSeek Harness 当前提供 Linux/macOS 运行时，但没有 Android 发行物；开发 Node 载体要求 Node >=22.19。
官方 Node 源码有 Android 交叉编译脚本，因此本项目在 GitHub Actions 中把 Node 24 交叉编译为 Android arm64
共享库 libnode.so，通过 JNI 的 node::Start() 在 App 进程内启动 Harness。

Android 10+ 不允许从 App 可写目录执行刚复制进去的二进制，因此 v0.5 不采用“把 node 可执行文件复制到
filesDir 再 chmod +x”的方案。Node 作为 APK 原生共享库装载；只有 JavaScript/node_modules 数据被首次启动时
解压到 App 私有目录。

v0.5 继承 v0.4 功能
------------------
- Harness 持久历史会话
- 多对话 + 按日期折叠侧边栏
- 收起/展开侧栏
- 全文历史搜索（Android 内置配置按首次搜索打开 SQLite）
- Token 输入/输出统计
- 上下文已用/剩余
- 缓存命中百分比
- 估算费用 + 自定义中转价格
- 一键回顶部
- Blue Fantasy / 鲸鱼娘壁纸、浅色、深色皮肤
- 字体比例、壁纸强度、高对比阅读模式
- API Key / Base URL / 自定义模型配置
- temperature / top_p（仅 DeepSeek 非思考 Off 模式有效）
- 最大输出 tokens

v0.5 新增
---------
- 默认“内置 Harness”运行方式，不需要 Termux。
- 设置中仍保留“外部 Harness”作为故障排查/远程连接后备。
- 内置 127.0.0.1:3081 高级采样代理，不需要额外脚本。
- 模型按钮提供一键预设：
    Flash · High
    Flash · Max
    Pro · High
    Pro · Max
    Pro · 关闭思考
  其中“Pro · Max”表示 DeepSeek-V4-Pro 模型 + Max reasoning effort，并不是另一个叫 Pro Max 的模型。
- 仍保留“更多模型 / 自定义”入口。

Android 内置 Harness 的兼容策略
------------------------------
为了避免 Android 上的桌面 PTY/子进程原生依赖，内置模式默认使用 mobile-chat Agent preset：
- 保留官方 Harness 的 Agent/session/model/LLM/context-meter/compaction 路径；
- 不挂载 bash/PTY/桌面 subprocess/本地图片附件等桌面工具；
- 定位是“纯聊天 Harness”，正好对应本项目用途。

如果将来要在 Android 内置版恢复完整 bash/PTY/代码工具，需要分别为 Android 编译对应原生模块；这不是
v0.5 第一版的目标。

构建
----
使用 build-apk-v0.5.yml。第一次 GitHub Actions 会交叉编译 Node 24，预计明显比 v0.4 慢；成功后 Node
运行时会进入 Actions cache，后续构建会快很多。当前只打 arm64-v8a APK，适合绝大多数现代 Android 手机。
