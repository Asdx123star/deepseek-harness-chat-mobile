DeepSeek Harness Chat v0.2（原生聊天版）
========================================

这版和 v0.1 最大区别：
- 不再用 WebView 套 Harness 网页。
- Android 原生聊天 UI 直接连接手机本机的 DeepSeek Harness API。
- 真正的对话仍由原版 Harness Session / Agent Loop / Prompt / Tools / Compaction 处理。
- 支持 Harness WebSocket 流式输出。
- 支持 reasoning（思考）折叠/展开。
- 支持历史 Session 续聊、新建 Session。
- 支持停止当前回合。
- 如果 Harness 真的请求工具升权，会弹“允许一次 / 拒绝”。
- 如果 Harness Agent 主动询问用户，会弹原生问题框。

运行前：
1. Termux 中照旧运行：dsh-android
2. 确认 http://127.0.0.1:3080 可访问
3. 用 Android Studio 打开 android/ 文件夹
4. 等 Gradle Sync 完成
5. Build > Build APK(s)
6. 安装生成的 app-debug.apk

第一次打开：
- App 会读取 Harness 已有 Session。
- 如果没有，会自动创建。
- 左上显示连接状态；右上“会话 / 新对话”。

重要：
- API Key 仍只放在 Termux/Harness 环境，不写进 APK。
- 不要把 Harness 的 3080 端口开放到局域网或公网。
- 当前 DeepSeek Harness 仍处于快速迭代期；如果后续官方 wire API 改动，App 也需要跟着改。
- 这版 UI 先保证“真 Harness + 能聊 + 能续 + 流式”，Markdown/LaTeX、自动标题、搜索会话可以放到 v0.3。
