package com.example.dshchat

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.method.LinkMovementMethod
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class ChatAdapter(
    private val items: MutableList<ChatMessage>
) : RecyclerView.Adapter<ChatAdapter.Holder>() {

    class Holder(val row: LinearLayout, val bubble: LinearLayout, val reasoning: TextView, val text: TextView) : RecyclerView.ViewHolder(row)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val context = parent.context
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 14), dp(context, 5), dp(context, 14), dp(context, 5))
            layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val bubble = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 14), dp(context, 10), dp(context, 14), dp(context, 10))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                width = 0
                weight = 0f
            }
        }
        val reasoning = TextView(context).apply {
            setTextColor(Color.rgb(160, 160, 168))
            textSize = 13f
            setLineSpacing(0f, 1.12f)
            visibility = View.GONE
        }
        val text = TextView(context).apply {
            setTextColor(Color.rgb(235, 235, 240))
            textSize = 16f
            setLineSpacing(0f, 1.18f)
            movementMethod = LinkMovementMethod.getInstance()
            setTextIsSelectable(true)
        }
        bubble.addView(reasoning)
        bubble.addView(text)
        row.addView(bubble)
        return Holder(row, bubble, reasoning, text)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        val context = holder.row.context
        val params = holder.bubble.layoutParams as LinearLayout.LayoutParams
        params.width = 0
        params.weight = 0f

        if (item.role == ChatRole.USER) {
            holder.row.gravity = Gravity.END
            params.width = ViewGroup.LayoutParams.WRAP_CONTENT
            holder.bubble.setBackgroundColor(Color.rgb(42, 75, 118))
        } else {
            holder.row.gravity = Gravity.START
            params.width = ViewGroup.LayoutParams.MATCH_PARENT
            holder.bubble.setBackgroundColor(Color.TRANSPARENT)
        }
        holder.bubble.layoutParams = params

        holder.text.text = when {
            item.streaming && item.text.isEmpty() -> "▍"
            item.streaming -> item.text + " ▍"
            else -> item.text
        }

        if (item.role == ChatRole.ASSISTANT && item.reasoning.isNotBlank()) {
            holder.reasoning.visibility = View.VISIBLE
            if (item.reasoningExpanded) {
                holder.reasoning.text = "思考  ▲\n${item.reasoning}\n"
                holder.reasoning.setTypeface(null, Typeface.NORMAL)
            } else {
                val preview = item.reasoning.replace('\n', ' ').trim().take(54)
                holder.reasoning.text = "思考  ▼  $preview${if (item.reasoning.length > 54) "…" else ""}\n"
            }
            holder.reasoning.setOnClickListener {
                item.reasoningExpanded = !item.reasoningExpanded
                notifyItemChanged(holder.bindingAdapterPosition)
            }
        } else {
            holder.reasoning.visibility = View.GONE
            holder.reasoning.setOnClickListener(null)
        }
    }

    override fun getItemCount(): Int = items.size

    companion object {
        private fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
    }
}
