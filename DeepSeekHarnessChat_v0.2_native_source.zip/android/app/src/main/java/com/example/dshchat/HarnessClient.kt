package com.example.dshchat

import android.os.Handler
import android.os.Looper
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

class HarnessClient(
    private val baseUrl: String = "http://127.0.0.1:3080",
    private val listener: Listener
) {
    interface Listener {
        fun onConnectionChanged(connected: Boolean, message: String)
        fun onMuxFrame(rpcId: String, payload: JSONObject)
    }

    private val main = Handler(Looper.getMainLooper())
    private val jsonMedia = "application/json".toMediaType()
    private val http = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var socket: WebSocket? = null
    private var stopped = false
    private var reconnectPosted = false

    fun start() {
        stopped = false
        openMux()
    }

    fun stop() {
        stopped = true
        reconnectPosted = false
        socket?.close(1000, "activity stopped")
        socket = null
    }

    private fun openMux() {
        if (stopped) return
        val wsUrl = baseUrl.replaceFirst("http://", "ws://").replaceFirst("https://", "wss://") + "/api/events.mux"
        val request = Request.Builder().url(wsUrl).build()
        socket = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                reconnectPosted = false
                main.post { listener.onConnectionChanged(true, "Harness 已连接") }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val wire = JSONObject(text)
                    if (wire.optString("type") != "server-request") return
                    val rpcId = wire.optString("rpcId")
                    val payload = wire.optJSONObject("payload") ?: return
                    main.post { listener.onMuxFrame(rpcId, payload) }
                } catch (_: Throwable) {
                    // Forward compatibility: ignore unknown/non-JSON frames.
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(code, reason)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                main.post { listener.onConnectionChanged(false, "Harness 连接已断开") }
                scheduleReconnect()
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                main.post { listener.onConnectionChanged(false, "未连接：先在 Termux 运行 dsh-android") }
                scheduleReconnect()
            }
        })
    }

    private fun scheduleReconnect() {
        if (stopped || reconnectPosted) return
        reconnectPosted = true
        main.postDelayed({
            reconnectPosted = false
            if (!stopped) openMux()
        }, 1500)
    }

    /**
     * Calls one Harness unary RPC. The returned string is the rpcId stamped into
     * the durable user message by session.prompt, which lets the UI reconcile
     * optimistic messages with the event stream.
     */
    fun rpc(
        method: String,
        payload: JSONObject = JSONObject(),
        callback: (rpcId: String, value: JSONObject?, error: String?) -> Unit
    ): String {
        val rpcId = UUID.randomUUID().toString()
        val body = JSONObject()
            .put("type", "client-request")
            .put("rpcId", rpcId)
            .put("method", method)
            .put("payload", payload)

        val request = Request.Builder()
            .url("$baseUrl/api/$method")
            .post(body.toString().toRequestBody(jsonMedia))
            .build()

        http.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                main.post { callback(rpcId, null, e.message ?: "网络请求失败") }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val raw = it.body?.string().orEmpty()
                    try {
                        val obj = JSONObject(raw)
                        val result = obj.optJSONObject("result")
                        if (result?.optBoolean("ok") == true) {
                            val anyValue = result.opt("value")
                            val value = when (anyValue) {
                                is JSONObject -> anyValue
                                else -> JSONObject().put("value", anyValue ?: JSONObject.NULL)
                            }
                            main.post { callback(rpcId, value, null) }
                        } else {
                            val err = result?.optJSONObject("error")
                            val message = err?.optString("message")?.takeIf { s -> s.isNotBlank() }
                                ?: "Harness RPC 失败"
                            main.post { callback(rpcId, null, message) }
                        }
                    } catch (t: Throwable) {
                        main.post { callback(rpcId, null, "无法解析 Harness 响应：${t.message ?: raw.take(120)}") }
                    }
                }
            }
        })
        return rpcId
    }

    fun respond(rpcId: String, value: JSONObject, callback: (error: String?) -> Unit = {}) {
        val body = JSONObject()
            .put("type", "client-response")
            .put("rpcId", rpcId)
            .put("result", JSONObject().put("ok", true).put("value", value))

        val request = Request.Builder()
            .url("$baseUrl/api/respond")
            .post(body.toString().toRequestBody(jsonMedia))
            .build()

        http.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                main.post { callback(e.message ?: "回答 Harness 交互失败") }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val raw = it.body?.string().orEmpty()
                    try {
                        val receipt = JSONObject(raw)
                        val accepted = receipt.optBoolean("accepted")
                        main.post { callback(if (accepted) null else "该请求已失效") }
                    } catch (t: Throwable) {
                        main.post { callback(t.message ?: "无法解析响应") }
                    }
                }
            }
        })
    }

    companion object {
        fun textContent(text: String): JSONArray = JSONArray().put(
            JSONObject().put("type", "text").put("text", text)
        )
    }
}
