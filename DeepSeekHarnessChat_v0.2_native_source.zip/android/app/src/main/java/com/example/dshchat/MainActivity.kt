package com.example.dshchat

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.time.ZoneId
import java.util.Date
import java.util.Locale
import java.util.TreeMap

class MainActivity : AppCompatActivity(), HarnessClient.Listener {
    private lateinit var client: HarnessClient
    private lateinit var status: TextView
    private lateinit var sessionLabel: TextView
    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private lateinit var sendButton: Button
    private lateinit var adapter: ChatAdapter

    private val messages = mutableListOf<ChatMessage>()
    private val sessions = mutableListOf<HarnessSession>()
    private val prefs by lazy { getSharedPreferences("dsh_chat", MODE_PRIVATE) }

    private var currentSessionId: String? = null
    private var connected = false
    private var sending = false
    private var historyGeneration = 0

    // One Harness turn may contain multiple model steps because tools run between calls.
    // We merge all of those steps into one visible assistant bubble while preserving
    // each step's final-vs-streaming state internally.
    private data class StepState(
        var streamText: String = "",
        var streamReasoning: String = "",
        var finalText: String = "",
        var finalReasoning: String = "",
        var finalized: Boolean = false
    )
    private val turnSteps = mutableMapOf<Int, TreeMap<Int, StepState>>()
    private val turnMessageKey = mutableMapOf<Int, String>()
    private val optimisticUserRpc = mutableMapOf<String, String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        client = HarnessClient(listener = this)
        client.start()
        // HTTP works even before the WebSocket reports open; this also makes the
        // app recover cleanly when Harness was already running before launch.
        refreshSessions(openPreferred = true)
    }

    override fun onDestroy() {
        client.stop()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 16, 18))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val title = TextView(this).apply {
            text = "Harness Chat"
            setTextColor(Color.WHITE)
            textSize = 18f
        }
        status = TextView(this).apply {
            text = "连接本机 Harness…"
            setTextColor(Color.rgb(150, 150, 158))
            textSize = 12f
        }
        sessionLabel = TextView(this).apply {
            text = ""
            setTextColor(Color.rgb(125, 125, 135))
            textSize = 11f
        }
        titleBox.addView(title)
        titleBox.addView(status)
        titleBox.addView(sessionLabel)
        top.addView(titleBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val history = Button(this).apply {
            text = "会话"
            setOnClickListener { showSessionPicker() }
        }
        val fresh = Button(this).apply {
            text = "新对话"
            setOnClickListener { createSession() }
        }
        top.addView(history)
        top.addView(fresh)

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity).apply { stackFromEnd = true }
            itemAnimator = null
            setBackgroundColor(Color.rgb(16, 16, 18))
        }
        adapter = ChatAdapter(messages)
        list.adapter = adapter

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(dp(10), dp(7), dp(10), dp(10))
            setBackgroundColor(Color.rgb(24, 24, 27))
        }
        input = EditText(this).apply {
            hint = "给 DeepSeek Harness 发消息…"
            setHintTextColor(Color.rgb(125, 125, 132))
            setTextColor(Color.WHITE)
            textSize = 16f
            minLines = 1
            maxLines = 7
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setBackgroundColor(Color.rgb(37, 37, 42))
        }
        sendButton = Button(this).apply {
            text = "发送"
            setOnClickListener {
                if (sending) cancelTurn() else sendPrompt()
            }
        }
        composer.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        composer.addView(sendButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(8)
        })

        root.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(composer, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    override fun onConnectionChanged(connected: Boolean, message: String) {
        this.connected = connected
        status.text = message
        status.setTextColor(if (connected) Color.rgb(111, 198, 135) else Color.rgb(210, 150, 90))
        if (connected) {
            refreshSessions(openPreferred = currentSessionId == null)
            currentSessionId?.let { loadHistory(it) }
        }
    }

    override fun onMuxFrame(rpcId: String, payload: JSONObject) {
        val type = payload.optString("type")
        val sid = payload.optString("sessionId")
        when (type) {
            "session/event" -> {
                if (sid == currentSessionId) payload.optJSONObject("event")?.let { handleLiveEvent(it) }
            }
            "session/subscribed" -> {
                if (sid == currentSessionId) status.text = "Harness 已连接"
            }
            "approval/requested" -> if (sid == currentSessionId) showApproval(rpcId, payload)
            "question/requested" -> if (sid == currentSessionId) showQuestions(rpcId, payload)
            "stream/error" -> toast(payload.optJSONObject("error")?.optString("message") ?: "Harness 流错误")
        }
    }

    private fun refreshSessions(openPreferred: Boolean) {
        client.rpc("session.list", JSONObject()) { _, value, error ->
            if (error != null) {
                status.text = "未连接：先运行 dsh-android"
                return@rpc
            }
            val arr = value?.optJSONArray("items") ?: JSONArray()
            sessions.clear()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                if (o.optString("origin") == "subagent") continue
                sessions += HarnessSession(
                    sessionId = o.optString("sessionId"),
                    updatedAt = o.optLong("updatedAt"),
                    running = o.optBoolean("running"),
                    blank = o.optBoolean("blank")
                )
            }
            if (!openPreferred) return@rpc
            val saved = prefs.getString("last_session", null)
            val target = sessions.firstOrNull { it.sessionId == saved }?.sessionId
                ?: sessions.firstOrNull { !it.blank }?.sessionId
                ?: sessions.firstOrNull()?.sessionId
            if (target != null) selectSession(target) else createSession()
        }
    }

    private fun createSession() {
        client.rpc("session.create", JSONObject()) { _, value, error ->
            if (error != null) {
                toast(error)
                return@rpc
            }
            val sid = value?.optString("sessionId").orEmpty()
            if (sid.isBlank()) {
                toast("Harness 没有返回 sessionId")
                return@rpc
            }
            sessions.add(0, HarnessSession(sid, System.currentTimeMillis(), false, true))
            selectSession(sid)
        }
    }

    private fun selectSession(sessionId: String) {
        currentSessionId = sessionId
        prefs.edit().putString("last_session", sessionId).apply()
        sessionLabel.text = "会话 ${sessionId.take(8)}"
        sending = sessions.firstOrNull { it.sessionId == sessionId }?.running == true
        updateSendState()
        loadHistory(sessionId)
    }

    private fun loadHistory(sessionId: String) {
        val generation = ++historyGeneration
        val payload = JSONObject().put("sessionId", sessionId).put("maxMessages", 200)
        client.rpc("session.history", payload) { _, value, error ->
            if (generation != historyGeneration || sessionId != currentSessionId) return@rpc
            if (error != null) {
                if (error.contains("not found", ignoreCase = true)) createSession() else toast(error)
                return@rpc
            }
            messages.clear()
            turnSteps.clear()
            turnMessageKey.clear()
            optimisticUserRpc.clear()
            val entries = value?.optJSONArray("events") ?: JSONArray()
            // HistoryEntry is { event, view? }. Render only human user messages and
            // append-origin assistant messages; compaction replacement rows are
            // model-facing summaries, not a second copy of the visible transcript.
            for (i in 0 until entries.length()) {
                val event = entries.optJSONObject(i)?.optJSONObject("event") ?: continue
                handleHistoryEvent(event)
            }
            adapter.notifyDataSetChanged()
            scrollBottom()
        }
    }

    private fun handleHistoryEvent(event: JSONObject) {
        when (event.optString("type")) {
            "user/message" -> {
                if (!isAppendOrigin(event)) return
                val msg = event.optJSONObject("data") ?: return
                val source = msg.optJSONObject("source")
                if (source?.optString("kind") != "user") return
                val text = extractText(msg.optJSONArray("content"))
                if (text.isNotBlank()) messages += ChatMessage("u-${event.optLong("seq")}", ChatRole.USER, text = text)
            }
            "assistant/message" -> {
                if (!isAppendOrigin(event)) return
                val d = event.optJSONObject("data") ?: return
                val turn = d.optInt("turn", -1)
                val step = d.optInt("step", -1)
                val msg = d.optJSONObject("message") ?: return
                applyFinalAssistant(turn, step, msg, streaming = false)
            }
            "turn/end" -> {
                val turn = event.optJSONObject("data")?.optInt("turn", -1) ?: -1
                if (turn >= 0) finishTurn(turn)
            }
        }
    }

    private fun handleLiveEvent(event: JSONObject) {
        when (event.optString("type")) {
            "user/message" -> {
                if (!isAppendOrigin(event)) return
                val msg = event.optJSONObject("data") ?: return
                val source = msg.optJSONObject("source")
                if (source?.optString("kind") != "user") return
                val rpcId = source.optString("rpcId")
                val text = extractText(msg.optJSONArray("content"))
                val optimisticKey = optimisticUserRpc.remove(rpcId)
                if (optimisticKey == null && text.isNotBlank()) {
                    messages += ChatMessage("u-${event.optLong("seq")}", ChatRole.USER, text = text)
                    adapter.notifyItemInserted(messages.lastIndex)
                }
                scrollBottom()
            }
            "assistant/chunk" -> {
                val d = event.optJSONObject("data") ?: return
                val turn = d.optInt("turn", -1)
                val step = d.optInt("step", -1)
                val chunk = d.optJSONObject("chunk") ?: return
                if (turn < 0 || step < 0) return
                val state = turnSteps.getOrPut(turn) { TreeMap() }.getOrPut(step) { StepState() }
                when (chunk.optString("type")) {
                    "text-delta" -> state.streamText += chunk.optString("text")
                    "reasoning-delta" -> state.streamReasoning += chunk.optString("text")
                    else -> return
                }
                sending = true
                updateSendState()
                renderTurn(turn, streaming = true)
            }
            "assistant/message" -> {
                if (!isAppendOrigin(event)) return
                val d = event.optJSONObject("data") ?: return
                applyFinalAssistant(
                    d.optInt("turn", -1),
                    d.optInt("step", -1),
                    d.optJSONObject("message") ?: return,
                    streaming = true
                )
            }
            "turn/end" -> {
                val d = event.optJSONObject("data") ?: return
                val turn = d.optInt("turn", -1)
                finishTurn(turn)
                val reason = d.optJSONObject("reason")
                if (reason?.optString("kind") == "error") {
                    val msg = reason.optJSONObject("error")?.optString("message")
                    if (!msg.isNullOrBlank()) toast(msg)
                }
            }
        }
    }

    private fun applyFinalAssistant(turn: Int, step: Int, msg: JSONObject, streaming: Boolean) {
        if (turn < 0 || step < 0) return
        val state = turnSteps.getOrPut(turn) { TreeMap() }.getOrPut(step) { StepState() }
        val blocks = msg.optJSONArray("content")
        state.finalText = extractText(blocks)
        state.finalReasoning = extractReasoning(blocks)
        state.finalized = true
        renderTurn(turn, streaming)
    }

    private fun renderTurn(turn: Int, streaming: Boolean) {
        val steps = turnSteps[turn] ?: return
        val text = steps.values.mapNotNull { s ->
            val v = if (s.finalized) s.finalText else s.streamText
            v.takeIf { it.isNotBlank() }
        }.joinToString("\n\n")
        val reasoning = steps.values.mapNotNull { s ->
            val v = if (s.finalized) s.finalReasoning else s.streamReasoning
            v.takeIf { it.isNotBlank() }
        }.joinToString("\n\n")
        if (text.isBlank() && reasoning.isBlank() && !streaming) return

        val key = turnMessageKey.getOrPut(turn) { "a-turn-$turn" }
        val index = messages.indexOfFirst { it.key == key }
        if (index < 0) {
            messages += ChatMessage(key, ChatRole.ASSISTANT, text, reasoning, streaming)
            adapter.notifyItemInserted(messages.lastIndex)
        } else {
            val item = messages[index]
            item.text = text
            item.reasoning = reasoning
            item.streaming = streaming
            adapter.notifyItemChanged(index)
        }
        scrollBottom()
    }

    private fun finishTurn(turn: Int) {
        sending = false
        updateSendState()
        val key = turnMessageKey[turn] ?: return
        val i = messages.indexOfFirst { it.key == key }
        if (i >= 0) {
            messages[i].streaming = false
            adapter.notifyItemChanged(i)
        }
    }

    private fun sendPrompt() {
        val sid = currentSessionId
        val text = input.text.toString().trim()
        if (sid == null) {
            createSession()
            toast("正在创建会话，再点一次发送")
            return
        }
        if (text.isBlank()) return

        input.setText("")
        val key = "u-local-${System.nanoTime()}"
        messages += ChatMessage(key, ChatRole.USER, text = text)
        adapter.notifyItemInserted(messages.lastIndex)
        scrollBottom()

        val payload = JSONObject()
            .put("sessionId", sid)
            .put("mode", "queue")
            .put("content", HarnessClient.textContent(text))
            .put("clientTimeZone", ZoneId.systemDefault().id)

        val rpcId = client.rpc("session.prompt", payload) { returnedRpcId, _, error ->
            if (error != null) {
                optimisticUserRpc.remove(returnedRpcId)
                messages += ChatMessage("sys-${System.nanoTime()}", ChatRole.ASSISTANT, text = "发送失败：$error")
                adapter.notifyItemInserted(messages.lastIndex)
                sending = false
                updateSendState()
                scrollBottom()
            }
        }
        optimisticUserRpc[rpcId] = key
        sending = true
        updateSendState()
        hideKeyboard()
    }

    private fun cancelTurn() {
        val sid = currentSessionId ?: return
        client.rpc("session.cancel", JSONObject().put("sessionId", sid)) { _, _, error ->
            if (error != null) toast(error)
        }
    }

    private fun updateSendState() {
        sendButton.text = if (sending) "停止" else "发送"
    }

    private fun showSessionPicker() {
        if (sessions.isEmpty()) {
            toast("还没有历史会话")
            return
        }
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
        val labels = sessions.take(30).map {
            val whenText = if (it.updatedAt > 0) fmt.format(Date(it.updatedAt)) else ""
            "${if (it.running) "● " else ""}$whenText   ${it.sessionId.take(8)}${if (it.blank) "  · 空白" else ""}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Harness 会话")
            .setItems(labels) { _, which -> selectSession(sessions[which].sessionId) }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showApproval(rpcId: String, p: JSONObject) {
        val tool = p.optString("toolName", "工具")
        val reason = p.optString("reason")
        val message = buildString {
            append("Harness 请求让工具执行一次需要额外授权的操作。\n\n")
            append("工具：$tool")
            if (reason.isNotBlank()) append("\n原因：$reason")
        }
        AlertDialog.Builder(this)
            .setTitle("需要授权")
            .setMessage(message)
            .setPositiveButton("允许一次") { _, _ -> answerApproval(rpcId, p, "allowed-once") }
            .setNegativeButton("拒绝") { _, _ -> answerApproval(rpcId, p, "rejected") }
            .setCancelable(false)
            .show()
    }

    private fun answerApproval(rpcId: String, p: JSONObject, outcome: String) {
        val value = JSONObject()
            .put("sessionId", p.optString("sessionId"))
            .put("approvalId", p.optString("approvalId"))
            .put("outcome", outcome)
        client.respond(rpcId, value) { it?.let(::toast) }
    }

    private fun showQuestions(rpcId: String, p: JSONObject) {
        val questions = p.optJSONArray("questions") ?: return
        val answers = JSONArray()
        askQuestionAt(rpcId, p.optString("sessionId"), questions, 0, answers)
    }

    private fun askQuestionAt(rpcId: String, sessionId: String, questions: JSONArray, index: Int, answers: JSONArray) {
        if (index >= questions.length()) {
            val value = JSONObject()
                .put("sessionId", sessionId)
                .put("answer", JSONObject().put("answers", answers))
            client.respond(rpcId, value) { it?.let(::toast) }
            return
        }
        val q = questions.optJSONObject(index) ?: return askQuestionAt(rpcId, sessionId, questions, index + 1, answers)
        val id = q.optString("id")
        val title = q.optString("header").takeIf { it.isNotBlank() } ?: "Harness 想问你"
        val questionText = buildString {
            append(q.optString("question"))
            val detail = q.optString("detail")
            if (detail.isNotBlank()) append("\n\n$detail")
        }
        val options = q.optJSONArray("options")
        val multi = q.optBoolean("multiSelect", false)

        if (options != null && options.length() > 0) {
            val labels = Array(options.length()) { i -> options.optJSONObject(i)?.optString("label").orEmpty() }
            if (multi) {
                val checked = BooleanArray(labels.size)
                AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(questionText)
                    .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
                    .setPositiveButton("确定") { _, _ ->
                        val selected = JSONArray()
                        labels.indices.filter { checked[it] }.forEach { selected.put(labels[it]) }
                        answers.put(JSONObject().put("id", id).put("selected", selected))
                        askQuestionAt(rpcId, sessionId, questions, index + 1, answers)
                    }
                    .setCancelable(false)
                    .show()
            } else {
                AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(questionText)
                    .setItems(labels) { _, which ->
                        answers.put(JSONObject().put("id", id).put("selected", JSONArray().put(labels[which])))
                        askQuestionAt(rpcId, sessionId, questions, index + 1, answers)
                    }
                    .setNegativeButton("取消") { _, _ ->
                        answers.put(JSONObject().put("id", id).put("selected", JSONArray()))
                        askQuestionAt(rpcId, sessionId, questions, index + 1, answers)
                    }
                    .setCancelable(false)
                    .show()
            }
        } else {
            val edit = EditText(this).apply {
                hint = "输入回答"
                setPadding(dp(16), dp(10), dp(16), dp(10))
            }
            val wrapper = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), 0, dp(18), 0)
                addView(edit)
            }
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(questionText)
                .setView(wrapper)
                .setPositiveButton("回答") { _, _ ->
                    val custom = edit.text.toString()
                    answers.put(JSONObject().put("id", id).put("selected", JSONArray()).put("custom", custom))
                    askQuestionAt(rpcId, sessionId, questions, index + 1, answers)
                }
                .setCancelable(false)
                .show()
        }
    }

    private fun isAppendOrigin(event: JSONObject): Boolean {
        val op = event.opt("surfaceOp")
        return op == null || op == JSONObject.NULL || op == "append"
    }

    private fun extractText(blocks: JSONArray?): String = extractBlocks(blocks, "text")
    private fun extractReasoning(blocks: JSONArray?): String = extractBlocks(blocks, "reasoning")

    private fun extractBlocks(blocks: JSONArray?, type: String): String {
        if (blocks == null) return ""
        val out = StringBuilder()
        for (i in 0 until blocks.length()) {
            val b = blocks.optJSONObject(i) ?: continue
            if (b.optString("type") != type) continue
            if (out.isNotEmpty()) out.append("\n\n")
            out.append(b.optString("text"))
        }
        return out.toString()
    }

    private fun scrollBottom() {
        list.post {
            if (messages.isNotEmpty()) list.scrollToPosition(messages.lastIndex)
        }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(input.windowToken, 0)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
