package com.example.dshchat

enum class ChatRole { USER, ASSISTANT, SYSTEM }

data class ChatMessage(
    val key: String,
    val role: ChatRole,
    var text: String = "",
    var reasoning: String = "",
    var streaming: Boolean = false,
    var reasoningExpanded: Boolean = false
)

data class HarnessSession(
    val sessionId: String,
    val updatedAt: Long,
    val running: Boolean,
    val blank: Boolean
)
