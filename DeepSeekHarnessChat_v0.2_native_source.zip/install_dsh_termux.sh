#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

echo '=== DeepSeek Harness Android / Termux 安装器 ==='
echo '适用于 Android 11+ / arm64，基于 2026-08-13 社区已跑通方案。'

pkg update -y
pkg install -y nodejs git clang make python cmake binutils pkg-config

NODE_VER="$(node -p 'process.versions.node')"
export CFLAGS='-target aarch64-linux-android30'
export CXXFLAGS='-target aarch64-linux-android30'

echo "Node: $NODE_VER"
echo '第一次安装可能会在 node-pty 处失败；脚本会自动补丁并重试。'

set +e
npm install -g @deepseek-ai/dsh
FIRST_RC=$?
set -e

G="$HOME/.cache/node-gyp/$NODE_VER/include/node/common.gypi"
if [ -f "$G" ]; then
  if ! grep -q "android_ndk_path%" "$G"; then
    python - "$G" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
needle = "'variables': {"
if needle not in s:
    raise SystemExit("找不到 common.gypi 的 variables 块，请把报错截图发给 ChatGPT。")
s = s.replace(needle, needle + "\n    'android_ndk_path%': '',", 1)
p.write_text(s)
print('已补丁:', p)
PY
  else
    echo 'common.gypi 已存在 android_ndk_path 补丁。'
  fi
else
  echo "没有找到 $G。若后续 node-pty 构建失败，请把完整报错截图发给 ChatGPT。"
fi

if [ "$FIRST_RC" -ne 0 ]; then
  echo '重试安装 DeepSeek Harness...'
  npm install -g @deepseek-ai/dsh
fi

DSH_ROOT="$(npm root -g)/@deepseek-ai/dsh"
if [ ! -d "$DSH_ROOT" ]; then
  echo "未找到全局 dsh 目录：$DSH_ROOT"
  exit 1
fi

echo '安装 sharp 的 WebAssembly fallback...'
cd "$DSH_ROOT"
npm install sharp @img/sharp-wasm32

STARTER="$PREFIX/bin/dsh-android"
cat > "$STARTER" <<EOS
#!/data/data/com.termux/files/usr/bin/bash
exec node --expose-internals "$DSH_ROOT/lib/bin.js" web "\$@"
EOS
chmod +x "$STARTER"

mkdir -p "$HOME/.dsh"

echo
echo '=== 安装完成 ==='
echo '1) 设置 API Key（只保存在你的手机里）：'
echo "   echo 'DEEPSEEK_API_KEY=sk-你的key' > ~/.dsh/.env"
echo '2) 启动 Harness：'
echo '   dsh-android'
echo '3) 看到 http://127.0.0.1:3080 后，不要关闭 Termux。'
echo '4) 然后打开 DeepSeek Harness Chat App。'
