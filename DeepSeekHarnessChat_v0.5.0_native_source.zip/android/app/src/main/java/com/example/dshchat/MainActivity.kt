package com.example.dshchat

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.time.ZoneId
import java.util.Date
import java.util.Locale
import java.util.TreeMap

class MainActivity : AppCompatActivity(), HarnessClient.Listener {
    private lateinit var client: HarnessClient
    private lateinit var rootFrame: FrameLayout
    private lateinit var wallpaper: ImageView
    private lateinit var veil: View
    private lateinit var contentRoot: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var composerCard: LinearLayout
    private lateinit var headerTitle: TextView
    private lateinit var status: TextView
    private lateinit var sessionLabel: TextView
    private lateinit var modelChip: TextView
    private lateinit var statsStrip: TextView
    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private lateinit var sendButton: TextView
    private lateinit var adapter: ChatAdapter

    private lateinit var sidebarScrim: View
    private lateinit var sidebarPanel: LinearLayout
    private lateinit var sidebarTitle: TextView
    private lateinit var sidebarSearch: EditText
    private lateinit var sidebarSessionsBox: LinearLayout
    private var sidebarOpen = false
    private val uiHandler = Handler(Looper.getMainLooper())
    private var pendingSearch: Runnable? = null
    private var sidebarSearchQuery: String = ""

    // Durable Harness projections. These are whole-session/provider reported counters,
    // not estimates made by the Android UI.
    private var uncachedInputTokens: Long = 0
    private var cacheReadTokens: Long = 0
    private var cacheWriteTokens: Long = 0
    private var outputTokens: Long = 0
    private var pressureTokens: Long? = null
    private var projectedTokens: Long? = null
    private var contextWindow: Long? = null
    private var systemTokens: Long = 0
    private var toolsTokens: Long = 0
    private var messageTokens: Long = 0
    private val projectionSeqs = mutableMapOf<String, Long>()
    private val samplingProxy by lazy { SamplingProxyClient() }
    private var currentProvider: String = "deepseek-official"
    private var currentModel: String = "deepseek-v4-flash"
    private var currentEffort: String = "high"

    private val messages = mutableListOf<ChatMessage>()
    private val sessions = mutableListOf<HarnessSession>()
    private val prefs by lazy { getSharedPreferences("dsh_chat", MODE_PRIVATE) }

    private var currentSessionId: String? = null
    private var connected = false
    private var sending = false
    private var historyGeneration = 0

    // One Harness turn may contain multiple model steps because tools run between calls.
    // We merge all of those steps into one visible assistant bubble while preserving
    // each step's final-vs-streaming state internally.
    private data class StepState(
        var streamText: String = "",
        var streamReasoning: String = "",
        var finalText: String = "",
        var finalReasoning: String = "",
        var finalized: Boolean = false
    )
    private val turnSteps = mutableMapOf<Int, TreeMap<Int, StepState>>()
    private val turnMessageKey = mutableMapOf<Int, String>()
    private val optimisticUserRpc = mutableMapOf<String, String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()
        applyAppearance()
        startRuntimeAndConnect()
    }

    private fun useEmbeddedRuntime(): Boolean = prefs.getBoolean("embedded_runtime", true)

    private fun startRuntimeAndConnect() {
        if (useEmbeddedRuntime()) {
            status.text = "正在启动内置 Harness…"
            EmbeddedHarnessRuntime.start(this) { state, detail ->
                if (!connected) {
                    status.text = when (state) {
                        EmbeddedHarnessRuntime.State.PREPARING -> "◌  正在解包内置 Harness…"
                        EmbeddedHarnessRuntime.State.STARTING -> "◌  正在启动内置 Harness…"
                        EmbeddedHarnessRuntime.State.RUNNING -> "●  内置 Harness 已就绪"
                        EmbeddedHarnessRuntime.State.FAILED -> "●  内置 Harness 启动失败：$detail"
                        EmbeddedHarnessRuntime.State.EXITED -> "●  内置 Harness 已停止"
                        else -> detail
                    }
                }
            }
        }
        connectClient()
        refreshSessions(openPreferred = true)
    }

    private fun connectClient() {
        if (::client.isInitialized) client.stop()
        val url = if (useEmbeddedRuntime()) {
            "http://127.0.0.1:3080"
        } else {
            prefs.getString("harness_url", "http://127.0.0.1:3080")
                ?.trim()?.trimEnd('/').orEmpty().ifBlank { "http://127.0.0.1:3080" }
        }
        client = HarnessClient(baseUrl = url, listener = this)
        client.start()
    }

    override fun onDestroy() {
        client.stop()
        super.onDestroy()
    }

    private fun buildUi() {
        rootFrame = FrameLayout(this)
        wallpaper = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        veil = View(this)
        contentRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipToPadding = false
        }
        rootFrame.addView(wallpaper, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        rootFrame.addView(veil, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        rootFrame.addView(contentRoot, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(9), dp(10), dp(9))
            elevation = dp(2).toFloat()
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        headerTitle = TextView(this).apply {
            text = "Harness Chat"
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
            setTextColor(Color.rgb(20, 36, 58))
            textSize = 19f
            includeFontPadding = false
        }
        status = TextView(this).apply {
            text = "连接本机 Harness…"
            setTextColor(Color.rgb(89, 105, 123))
            textSize = 11.5f
            includeFontPadding = false
            setPadding(0, dp(3), 0, 0)
        }
        sessionLabel = TextView(this).apply {
            text = ""
            setTextColor(Color.rgb(111, 126, 143))
            textSize = 10.5f
            includeFontPadding = false
            visibility = View.GONE
        }
        titleBox.addView(headerTitle)
        titleBox.addView(status)
        titleBox.addView(sessionLabel)
        topBar.addView(titleBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        topBar.addView(iconButton("☰", "历史会话") { toggleSidebar() })
        topBar.addView(iconButton("⇧", "回到最上方") { scrollTop() })
        topBar.addView(iconButton("＋", "新对话") { createSession() })
        topBar.addView(iconButton("⚙", "设置") { showSettings() })

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity).apply { stackFromEnd = true }
            itemAnimator = null
            setBackgroundColor(Color.TRANSPARENT)
            clipToPadding = false
            setPadding(0, dp(10), 0, dp(10))
        }
        adapter = ChatAdapter(messages) { appearance() }
        list.adapter = adapter

        composerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(9))
            elevation = dp(10).toFloat()
            background = rounded(Color.argb(242, 255, 255, 255), 22, Color.argb(100, 143, 165, 194), 1)
        }
        input = EditText(this).apply {
            hint = "给 DeepSeek Harness 发消息…"
            setHintTextColor(Color.rgb(132, 145, 161))
            setTextColor(Color.rgb(21, 32, 47))
            textSize = 16.5f
            minLines = 1
            maxLines = 7
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(4), dp(5), dp(4), dp(7))
            background = null
            setSingleLine(false)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        input.minHeight = dp(48)
        composerCard.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        statsStrip = TextView(this).apply {
            text = "上下文 —  ·  Token —  ·  缓存 —  ·  费用 —"
            textSize = 10.8f
            includeFontPadding = false
            maxLines = 2
            setTextColor(Color.rgb(99, 115, 134))
            setPadding(dp(4), dp(1), dp(4), dp(6))
            isClickable = true
            isFocusable = true
            setOnClickListener { showTelemetryDetails() }
        }
        composerCard.addView(statsStrip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val composerBottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        modelChip = TextView(this).apply {
            text = "模型 · 加载中…  ▾"
            textSize = 12.5f
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
            setTextColor(Color.rgb(49, 69, 96))
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = rounded(Color.argb(125, 230, 239, 250), 14)
            isClickable = true
            isFocusable = true
            setOnClickListener { showModelPicker() }
        }
        sendButton = TextView(this).apply {
            text = "↑"
            textSize = 24f
            gravity = Gravity.CENTER
            setTypeface(Typeface.DEFAULT_BOLD)
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(118, 164, 226), 22)
            isClickable = true
            isFocusable = true
            setOnClickListener { if (sending) cancelTurn() else sendPrompt() }
        }
        composerBottom.addView(modelChip, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        composerBottom.addView(sendButton, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        composerCard.addView(composerBottom)

        val composerShell = FrameLayout(this).apply {
            setPadding(dp(12), dp(4), dp(12), dp(10))
            clipToPadding = false
        }
        composerShell.addView(composerCard, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        contentRoot.addView(topBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        contentRoot.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        contentRoot.addView(composerShell, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        buildSidebar()
        setContentView(rootFrame)

        WindowCompat.getInsetsController(window, rootFrame).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }
        ViewCompat.setOnApplyWindowInsetsListener(rootFrame) { _, insets ->
            val sys = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            contentRoot.setPadding(0, sys.top, 0, 0)
            sidebarPanel.setPadding(0, sys.top, 0, sys.bottom)
            composerShell.setPadding(dp(12), dp(4), dp(12), maxOf(dp(10), sys.bottom, ime.bottom))
            if (ime.bottom > 0) scrollBottom()
            insets
        }
        input.setOnFocusChangeListener { _, focused -> if (focused) input.postDelayed({ scrollBottom() }, 180) }
    }

    private fun iconButton(symbol: String, description: String, click: () -> Unit): TextView = TextView(this).apply {
        text = symbol
        contentDescription = description
        textSize = 22f
        gravity = Gravity.CENTER
        setTextColor(Color.rgb(31, 52, 78))
        setPadding(dp(7), dp(5), dp(7), dp(5))
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
        background = rounded(Color.TRANSPARENT, 16)
    }

    override fun onConnectionChanged(connected: Boolean, message: String) {
        this.connected = connected
        if (connected && useEmbeddedRuntime()) EmbeddedHarnessRuntime.markServerReady()
        status.text = if (connected) {
            if (useEmbeddedRuntime()) "●  内置 Harness 已连接" else "●  Harness 已连接"
        } else {
            if (useEmbeddedRuntime() && EmbeddedHarnessRuntime.state == EmbeddedHarnessRuntime.State.FAILED)
                "●  内置 Harness 启动失败：${EmbeddedHarnessRuntime.detail}" else "●  $message"
        }
        status.setTextColor(if (connected) Color.rgb(42, 143, 91) else Color.rgb(190, 102, 65))
        if (connected) {
            refreshSessions(openPreferred = currentSessionId == null)
            currentSessionId?.let {
                loadHistory(it)
                refreshModelChip()
            }
        }
    }

    override fun onMuxFrame(rpcId: String, payload: JSONObject) {
        val type = payload.optString("type")
        val sid = payload.optString("sessionId")
        when (type) {
            "session/event" -> {
                if (sid == currentSessionId) payload.optJSONObject("event")?.let { handleLiveEvent(it) }
            }
            "session/subscribed" -> {
                if (sid == currentSessionId) status.text = "Harness 已连接"
            }
            "session/projection" -> {
                val key = payload.optString("key")
                val seq = payload.optLong("seq", -1L)
                applyProjectionValue(sid, key, payload.opt("value"), seq)
            }
            "approval/requested" -> if (sid == currentSessionId) showApproval(rpcId, payload)
            "question/requested" -> if (sid == currentSessionId) showQuestions(rpcId, payload)
            "stream/error" -> toast(payload.optJSONObject("error")?.optString("message") ?: "Harness 流错误")
        }
    }

    private fun refreshSessions(openPreferred: Boolean) {
        client.rpc("session.list", JSONObject()) { _, value, error ->
            if (error != null) {
                status.text = "未连接：先运行 dsh-android"
                return@rpc
            }
            val arr = value?.optJSONArray("items") ?: JSONArray()
            sessions.clear()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                if (o.optString("origin") == "subagent") continue
                val projectionValues = o.optJSONObject("projections")?.optJSONObject("values")
                val title = projectionValues?.opt("title")?.let { v ->
                    if (v == JSONObject.NULL) null else v.toString().takeIf { it.isNotBlank() }
                }
                sessions += HarnessSession(
                    sessionId = o.optString("sessionId"),
                    updatedAt = o.optLong("updatedAt"),
                    running = o.optBoolean("running"),
                    blank = o.optBoolean("blank"),
                    title = title
                )
            }
            renderSidebarSessions()
            if (!openPreferred) return@rpc
            val saved = prefs.getString("last_session", null)
            val target = sessions.firstOrNull { it.sessionId == saved }?.sessionId
                ?: sessions.firstOrNull { !it.blank }?.sessionId
                ?: sessions.firstOrNull()?.sessionId
            if (target != null) selectSession(target) else createSession()
        }
    }

    private fun createSession() {
        client.rpc("session.create", JSONObject()) { _, value, error ->
            if (error != null) {
                toast(error)
                return@rpc
            }
            val sid = value?.optString("sessionId").orEmpty()
            if (sid.isBlank()) {
                toast("Harness 没有返回 sessionId")
                return@rpc
            }
            sessions.add(0, HarnessSession(sid, System.currentTimeMillis(), false, true, title = "新对话"))
            selectSession(sid)
        }
    }

    private fun selectSession(sessionId: String) {
        currentSessionId = sessionId
        prefs.edit().putString("last_session", sessionId).apply()
        val row = sessions.firstOrNull { it.sessionId == sessionId }
        sessionLabel.text = row?.title?.takeIf { it.isNotBlank() } ?: "会话 ${sessionId.take(8)}"
        sessionLabel.visibility = View.VISIBLE
        sending = row?.running == true
        resetTelemetry()
        updateSendState()
        closeSidebar()
        loadHistory(sessionId)
        refreshModelChip()
    }

    private fun loadHistory(sessionId: String) {
        val generation = ++historyGeneration
        val payload = JSONObject().put("sessionId", sessionId).put("maxMessages", 1000)
        client.rpc("session.history", payload) { _, value, error ->
            if (generation != historyGeneration || sessionId != currentSessionId) return@rpc
            if (error != null) {
                if (error.contains("not found", ignoreCase = true)) createSession() else toast(error)
                return@rpc
            }
            messages.clear()
            turnSteps.clear()
            turnMessageKey.clear()
            optimisticUserRpc.clear()
            val entries = value?.optJSONArray("events") ?: JSONArray()
            // HistoryEntry is { event, view? }. Render only human user messages and
            // append-origin assistant messages; compaction replacement rows are
            // model-facing summaries, not a second copy of the visible transcript.
            for (i in 0 until entries.length()) {
                val event = entries.optJSONObject(i)?.optJSONObject("event") ?: continue
                handleHistoryEvent(event)
            }
            applyProjectionBlock(sessionId, value?.optJSONObject("projections"))
            adapter.notifyDataSetChanged()
            scrollBottom()
        }
    }

    private fun handleHistoryEvent(event: JSONObject) {
        when (event.optString("type")) {
            "user/message" -> {
                if (!isAppendOrigin(event)) return
                val msg = event.optJSONObject("data") ?: return
                val source = msg.optJSONObject("source")
                if (source?.optString("kind") != "user") return
                val text = extractText(msg.optJSONArray("content"))
                if (text.isNotBlank()) messages += ChatMessage("u-${event.optLong("seq")}", ChatRole.USER, text = text)
            }
            "assistant/message" -> {
                if (!isAppendOrigin(event)) return
                val d = event.optJSONObject("data") ?: return
                val turn = d.optInt("turn", -1)
                val step = d.optInt("step", -1)
                val msg = d.optJSONObject("message") ?: return
                applyFinalAssistant(turn, step, msg, streaming = false)
            }
            "turn/end" -> {
                val turn = event.optJSONObject("data")?.optInt("turn", -1) ?: -1
                if (turn >= 0) finishTurn(turn)
            }
        }
    }

    private fun handleLiveEvent(event: JSONObject) {
        when (event.optString("type")) {
            "user/message" -> {
                if (!isAppendOrigin(event)) return
                val msg = event.optJSONObject("data") ?: return
                val source = msg.optJSONObject("source")
                if (source?.optString("kind") != "user") return
                val rpcId = source.optString("rpcId")
                val text = extractText(msg.optJSONArray("content"))
                val optimisticKey = optimisticUserRpc.remove(rpcId)
                if (optimisticKey == null && text.isNotBlank()) {
                    messages += ChatMessage("u-${event.optLong("seq")}", ChatRole.USER, text = text)
                    adapter.notifyItemInserted(messages.lastIndex)
                }
                scrollBottom()
            }
            "assistant/chunk" -> {
                val d = event.optJSONObject("data") ?: return
                val turn = d.optInt("turn", -1)
                val step = d.optInt("step", -1)
                val chunk = d.optJSONObject("chunk") ?: return
                if (turn < 0 || step < 0) return
                val state = turnSteps.getOrPut(turn) { TreeMap() }.getOrPut(step) { StepState() }
                when (chunk.optString("type")) {
                    "text-delta" -> state.streamText += chunk.optString("text")
                    "reasoning-delta" -> state.streamReasoning += chunk.optString("text")
                    else -> return
                }
                sending = true
                updateSendState()
                renderTurn(turn, streaming = true)
            }
            "assistant/message" -> {
                if (!isAppendOrigin(event)) return
                val d = event.optJSONObject("data") ?: return
                applyFinalAssistant(
                    d.optInt("turn", -1),
                    d.optInt("step", -1),
                    d.optJSONObject("message") ?: return,
                    streaming = true
                )
            }
            "turn/end" -> {
                val d = event.optJSONObject("data") ?: return
                val turn = d.optInt("turn", -1)
                finishTurn(turn)
                val reason = d.optJSONObject("reason")
                if (reason?.optString("kind") == "error") {
                    val msg = reason.optJSONObject("error")?.optString("message")
                    if (!msg.isNullOrBlank()) toast(msg)
                }
            }
        }
    }

    private fun applyFinalAssistant(turn: Int, step: Int, msg: JSONObject, streaming: Boolean) {
        if (turn < 0 || step < 0) return
        val state = turnSteps.getOrPut(turn) { TreeMap() }.getOrPut(step) { StepState() }
        val blocks = msg.optJSONArray("content")
        state.finalText = extractText(blocks)
        state.finalReasoning = extractReasoning(blocks)
        state.finalized = true
        renderTurn(turn, streaming)
    }

    private fun renderTurn(turn: Int, streaming: Boolean) {
        val steps = turnSteps[turn] ?: return
        val text = steps.values.mapNotNull { s ->
            val v = if (s.finalized) s.finalText else s.streamText
            v.takeIf { it.isNotBlank() }
        }.joinToString("\n\n")
        val reasoning = steps.values.mapNotNull { s ->
            val v = if (s.finalized) s.finalReasoning else s.streamReasoning
            v.takeIf { it.isNotBlank() }
        }.joinToString("\n\n")
        if (text.isBlank() && reasoning.isBlank() && !streaming) return

        val key = turnMessageKey.getOrPut(turn) { "a-turn-$turn" }
        val index = messages.indexOfFirst { it.key == key }
        if (index < 0) {
            messages += ChatMessage(key, ChatRole.ASSISTANT, text, reasoning, streaming)
            adapter.notifyItemInserted(messages.lastIndex)
        } else {
            val item = messages[index]
            item.text = text
            item.reasoning = reasoning
            item.streaming = streaming
            adapter.notifyItemChanged(index)
        }
        scrollBottom()
    }

    private fun finishTurn(turn: Int) {
        sending = false
        updateSendState()
        val key = turnMessageKey[turn] ?: return
        val i = messages.indexOfFirst { it.key == key }
        if (i >= 0) {
            messages[i].streaming = false
            adapter.notifyItemChanged(i)
        }
    }

    private fun sendPrompt() {
        val sid = currentSessionId
        val text = input.text.toString().trim()
        if (sid == null) {
            createSession()
            toast("正在创建会话，再点一次发送")
            return
        }
        if (text.isBlank()) return

        input.setText("")
        val key = "u-local-${System.nanoTime()}"
        messages += ChatMessage(key, ChatRole.USER, text = text)
        adapter.notifyItemInserted(messages.lastIndex)
        scrollBottom()

        val payload = JSONObject()
            .put("sessionId", sid)
            .put("mode", "queue")
            .put("content", HarnessClient.textContent(text))
            .put("clientTimeZone", ZoneId.systemDefault().id)

        val rpcId = client.rpc("session.prompt", payload) { returnedRpcId, _, error ->
            if (error != null) {
                optimisticUserRpc.remove(returnedRpcId)
                messages += ChatMessage("sys-${System.nanoTime()}", ChatRole.ASSISTANT, text = "发送失败：$error")
                adapter.notifyItemInserted(messages.lastIndex)
                sending = false
                updateSendState()
                scrollBottom()
            }
        }
        optimisticUserRpc[rpcId] = key
        sending = true
        updateSendState()
    }

    private fun cancelTurn() {
        val sid = currentSessionId ?: return
        client.rpc("session.cancel", JSONObject().put("sessionId", sid)) { _, _, error ->
            if (error != null) toast(error)
        }
    }

    private fun updateSendState() {
        sendButton.text = if (sending) "■" else "↑"
        sendButton.textSize = if (sending) 17f else 24f
        sendButton.background = rounded(
            if (sending) Color.rgb(92, 108, 128) else Color.rgb(108, 158, 225), 22
        )
    }

    private fun buildSidebar() {
        sidebarScrim = View(this).apply {
            setBackgroundColor(Color.argb(95, 18, 29, 43))
            visibility = View.GONE
            isClickable = true
            setOnClickListener { closeSidebar() }
        }
        rootFrame.addView(sidebarScrim, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        sidebarPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            elevation = dp(18).toFloat()
        }
        val width = (resources.displayMetrics.widthPixels * 0.86f).toInt().coerceAtMost(dp(380))
        rootFrame.addView(sidebarPanel, FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START))

        val sidebarHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(10), dp(8))
        }
        sidebarTitle = TextView(this).apply {
            text = "对话记录"
            textSize = 18f
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
            setTextColor(Color.rgb(27, 48, 72))
        }
        sidebarHeader.addView(sidebarTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sidebarHeader.addView(iconButton("＋", "新对话") { createSession() })
        sidebarHeader.addView(iconButton("‹", "收起侧边栏") { closeSidebar() })
        sidebarPanel.addView(sidebarHeader)

        sidebarSearch = EditText(this).apply {
            hint = "搜索所有 Harness 对话…"
            setSingleLine(true)
            textSize = 14f
            setTextColor(Color.rgb(27, 42, 61))
            setHintTextColor(Color.rgb(129, 143, 160))
            setPadding(dp(12), dp(9), dp(12), dp(9))
            background = rounded(Color.argb(220, 246, 250, 254), 14, Color.argb(110, 180, 198, 219), 1)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    sidebarSearchQuery = s?.toString()?.trim().orEmpty()
                    pendingSearch?.let(uiHandler::removeCallbacks)
                    val task = Runnable {
                        if (sidebarSearchQuery.isBlank()) {
                            sessions.forEach { it.searchSnippet = null }
                            renderSidebarSessions()
                        } else searchSessionHistory(sidebarSearchQuery)
                    }
                    pendingSearch = task
                    uiHandler.postDelayed(task, 320)
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        sidebarPanel.addView(sidebarSearch, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(12); marginEnd = dp(12); bottomMargin = dp(6) })

        val scroll = ScrollView(this)
        sidebarSessionsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(18))
        }
        scroll.addView(sidebarSessionsBox, ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        sidebarPanel.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun toggleSidebar() {
        if (sidebarOpen) closeSidebar() else openSidebar()
    }

    private fun openSidebar() {
        sidebarOpen = true
        sidebarScrim.visibility = View.VISIBLE
        sidebarPanel.visibility = View.VISIBLE
        refreshSessions(openPreferred = false)
        renderSidebarSessions()
    }

    private fun closeSidebar() {
        if (!::sidebarPanel.isInitialized) return
        sidebarOpen = false
        sidebarScrim.visibility = View.GONE
        sidebarPanel.visibility = View.GONE
        sidebarSearch.clearFocus()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (sidebarOpen) closeSidebar() else super.onBackPressed()
    }

    private fun searchSessionHistory(query: String) {
        val submitted = query
        client.rpc("session.search", JSONObject().put("query", submitted)) { _, value, error ->
            if (submitted != sidebarSearchQuery) return@rpc
            if (error != null) {
                toast("搜索失败：$error")
                return@rpc
            }
            sessions.forEach { it.searchSnippet = null }
            val hits = value?.optJSONArray("items") ?: JSONArray()
            val ordered = mutableListOf<HarnessSession>()
            for (i in 0 until hits.length()) {
                val hit = hits.optJSONObject(i) ?: continue
                val sid = hit.optString("sessionId")
                val row = sessions.firstOrNull { it.sessionId == sid } ?: continue
                row.searchSnippet = hit.optString("snippet").takeIf { it.isNotBlank() }
                ordered += row
            }
            renderSidebarSessions(ordered)
        }
    }

    private fun renderSidebarSessions(overrideRows: List<HarnessSession>? = null) {
        if (!::sidebarSessionsBox.isInitialized) return
        sidebarSessionsBox.removeAllViews()
        val searching = sidebarSearchQuery.isNotBlank()
        val rows = overrideRows ?: sessions.filter { !it.blank || it.sessionId == currentSessionId }
        if (rows.isEmpty()) {
            sidebarSessionsBox.addView(TextView(this).apply {
                text = if (searching) "没有找到匹配的对话" else "还没有历史对话"
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(105, 119, 136))
                setPadding(dp(10), dp(28), dp(10), dp(28))
            })
            return
        }
        if (searching) {
            sidebarSessionsBox.addView(sidebarGroupHeader("搜索结果", false, null))
            rows.forEach { sidebarSessionsBox.addView(sidebarSessionRow(it)) }
            return
        }
        val groups = linkedMapOf<String, MutableList<HarnessSession>>()
        rows.sortedByDescending { it.updatedAt }.forEach { row ->
            groups.getOrPut(sessionDateGroup(row.updatedAt)) { mutableListOf() }.add(row)
        }
        groups.forEach { (name, groupRows) ->
            val key = "session_group_collapsed_${name.hashCode()}"
            val collapsed = prefs.getBoolean(key, false)
            sidebarSessionsBox.addView(sidebarGroupHeader(name, collapsed) {
                prefs.edit().putBoolean(key, !collapsed).apply()
                renderSidebarSessions()
            })
            if (!collapsed) groupRows.forEach { sidebarSessionsBox.addView(sidebarSessionRow(it)) }
        }
    }

    private fun sidebarGroupHeader(name: String, collapsed: Boolean, click: (() -> Unit)?): TextView = TextView(this).apply {
        text = if (click == null) name else "${if (collapsed) "▸" else "▾"}  $name"
        textSize = 12f
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
        setTextColor(if (appearance().dark) Color.rgb(177, 197, 219) else Color.rgb(91, 108, 128))
        setPadding(dp(8), dp(12), dp(8), dp(5))
        if (click != null) {
            isClickable = true
            setOnClickListener { click() }
        }
    }

    private fun sidebarSessionRow(row: HarnessSession): View {
        val dark = appearance().dark
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11), dp(9), dp(11), dp(9))
            background = rounded(
                if (row.sessionId == currentSessionId) {
                    if (dark) Color.argb(185, 56, 83, 113) else Color.argb(150, 222, 238, 252)
                } else Color.TRANSPARENT,
                13
            )
            isClickable = true
            setOnClickListener { selectSession(row.sessionId) }
        }
        val title = row.title?.trim().takeUnless { it.isNullOrBlank() }
            ?: row.searchSnippet?.lineSequence()?.firstOrNull()?.take(32)
            ?: "会话 ${row.sessionId.take(8)}"
        box.addView(TextView(this).apply {
            text = "${if (row.running) "● " else ""}$title"
            maxLines = 1
            textSize = 14f
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
            setTextColor(if (dark) Color.rgb(236, 244, 252) else Color.rgb(30, 48, 69))
        })
        val meta = buildString {
            if (row.updatedAt > 0) append(SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(row.updatedAt)))
            if (row.blank) append("  ·  空白")
        }
        if (meta.isNotBlank()) box.addView(TextView(this).apply {
            text = meta
            textSize = 10.5f
            setTextColor(if (dark) Color.rgb(156, 177, 199) else Color.rgb(113, 127, 144))
            setPadding(0, dp(3), 0, 0)
        })
        row.searchSnippet?.let { snippet ->
            box.addView(TextView(this).apply {
                text = snippet.replace('\n', ' ').take(150)
                maxLines = 2
                textSize = 11.5f
                setTextColor(if (dark) Color.rgb(184, 202, 222) else Color.rgb(78, 96, 117))
                setPadding(0, dp(4), 0, 0)
            })
        }
        return box
    }

    private fun sessionDateGroup(time: Long): String {
        if (time <= 0) return "更早"
        val now = System.currentTimeMillis()
        val day = 24L * 60L * 60L * 1000L
        val delta = (now - time).coerceAtLeast(0L)
        return when {
            delta < day -> "今天"
            delta < day * 2 -> "昨天"
            delta < day * 7 -> "最近 7 天"
            else -> "更早"
        }
    }

    private fun showApproval(rpcId: String, p: JSONObject) {
        val tool = p.optString("toolName", "工具")
        val reason = p.optString("reason")
        val message = buildString {
            append("Harness 请求让工具执行一次需要额外授权的操作。\n\n")
            append("工具：$tool")
            if (reason.isNotBlank()) append("\n原因：$reason")
        }
        AlertDialog.Builder(this)
            .setTitle("需要授权")
            .setMessage(message)
            .setPositiveButton("允许一次") { _, _ -> answerApproval(rpcId, p, "allowed-once") }
            .setNegativeButton("拒绝") { _, _ -> answerApproval(rpcId, p, "rejected") }
            .setCancelable(false)
            .show()
    }

    private fun answerApproval(rpcId: String, p: JSONObject, outcome: String) {
        val value = JSONObject()
            .put("sessionId", p.optString("sessionId"))
            .put("approvalId", p.optString("approvalId"))
            .put("outcome", outcome)
        client.respond(rpcId, value) { it?.let(::toast) }
    }

    private fun showQuestions(rpcId: String, p: JSONObject) {
        val questions = p.optJSONArray("questions") ?: return
        val answers = JSONArray()
        askQuestionAt(rpcId, p.optString("sessionId"), questions, 0, answers)
    }

    private fun askQuestionAt(rpcId: String, sessionId: String, questions: JSONArray, index: Int, answers: JSONArray) {
        if (index >= questions.length()) {
            val value = JSONObject()
                .put("sessionId", sessionId)
                .put("answer", JSONObject().put("answers", answers))
            client.respond(rpcId, value) { it?.let(::toast) }
            return
        }
        val q = questions.optJSONObject(index) ?: return askQuestionAt(rpcId, sessionId, questions, index + 1, answers)
        val id = q.optString("id")
        val title = q.optString("header").takeIf { it.isNotBlank() } ?: "Harness 想问你"
        val questionText = buildString {
            append(q.optString("question"))
            val detail = q.optString("detail")
            if (detail.isNotBlank()) append("\n\n$detail")
        }
        val options = q.optJSONArray("options")
        val multi = q.optBoolean("multiSelect", false)

        if (options != null && options.length() > 0) {
            val labels = Array(options.length()) { i -> options.optJSONObject(i)?.optString("label").orEmpty() }
            if (multi) {
                val checked = BooleanArray(labels.size)
                AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(questionText)
                    .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
                    .setPositiveButton("确定") { _, _ ->
                        val selected = JSONArray()
                        labels.indices.filter { checked[it] }.forEach { selected.put(labels[it]) }
                        answers.put(JSONObject().put("id", id).put("selected", selected))
                        askQuestionAt(rpcId, sessionId, questions, index + 1, answers)
                    }
                    .setCancelable(false)
                    .show()
            } else {
                AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(questionText)
                    .setItems(labels) { _, which ->
                        answers.put(JSONObject().put("id", id).put("selected", JSONArray().put(labels[which])))
                        askQuestionAt(rpcId, sessionId, questions, index + 1, answers)
                    }
                    .setNegativeButton("取消") { _, _ ->
                        answers.put(JSONObject().put("id", id).put("selected", JSONArray()))
                        askQuestionAt(rpcId, sessionId, questions, index + 1, answers)
                    }
                    .setCancelable(false)
                    .show()
            }
        } else {
            val edit = EditText(this).apply {
                hint = "输入回答"
                setPadding(dp(16), dp(10), dp(16), dp(10))
            }
            val wrapper = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), 0, dp(18), 0)
                addView(edit)
            }
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(questionText)
                .setView(wrapper)
                .setPositiveButton("回答") { _, _ ->
                    val custom = edit.text.toString()
                    answers.put(JSONObject().put("id", id).put("selected", JSONArray()).put("custom", custom))
                    askQuestionAt(rpcId, sessionId, questions, index + 1, answers)
                }
                .setCancelable(false)
                .show()
        }
    }

    private data class ModelChoice(
        val provider: String,
        val id: String,
        val name: String,
        val efforts: List<String>,
        val defaultEffort: String?
    )

    private fun refreshModelChip() {
        val sid = currentSessionId ?: return
        client.rpc("session.models", JSONObject().put("sessionId", sid)) { _, value, error ->
            if (error != null || value == null) {
                modelChip.text = "模型 · 点击配置  ▾"
                return@rpc
            }
            val current = value.optJSONObject("current") ?: return@rpc
            currentProvider = current.optString("provider", "deepseek-official")
            currentModel = current.optString("model", "deepseek-v4-flash")
            currentEffort = current.optString("reasoningEffort", "high").ifBlank { "high" }
            val display = findModelDisplayName(value.optJSONArray("groups"), currentProvider, currentModel) ?: currentModel
            modelChip.text = "$display · ${effortName(currentEffort)}  ▾"
            updateTelemetryUi()
        }
    }

    private fun findModelDisplayName(groups: JSONArray?, provider: String, model: String): String? {
        if (groups == null) return null
        for (i in 0 until groups.length()) {
            val g = groups.optJSONObject(i) ?: continue
            if (g.optString("id") != provider) continue
            val models = g.optJSONArray("models") ?: continue
            for (j in 0 until models.length()) {
                val m = models.optJSONObject(j) ?: continue
                if (m.optString("id") == model) return m.optString("name").ifBlank { model }
            }
        }
        return null
    }

    private fun showModelPicker() {
        if (currentSessionId == null) return toast("先创建一个会话")
        val labels = arrayOf(
            "⚡ Flash · High",
            "⚡ Flash · Max",
            "◆ Pro · High",
            "◆ Pro · Max",
            "◆ Pro · 关闭思考",
            "更多模型 / 自定义…"
        )
        AlertDialog.Builder(this)
            .setTitle("DeepSeek 模型与思考强度")
            .setMessage("这里的 Pro · Max 指：V4 Pro 模型 + Max 思考强度。模型和思考档位是两个独立设置。")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> selectModel("deepseek-official", "deepseek-v4-flash", "high")
                    1 -> selectModel("deepseek-official", "deepseek-v4-flash", "max")
                    2 -> selectModel("deepseek-official", "deepseek-v4-pro", "high")
                    3 -> selectModel("deepseek-official", "deepseek-v4-pro", "max")
                    4 -> selectModel("deepseek-official", "deepseek-v4-pro", "off")
                    else -> showFullModelPicker()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showFullModelPicker() {
        val sid = currentSessionId ?: return toast("先创建一个会话")
        client.rpc("session.models", JSONObject().put("sessionId", sid)) { _, value, error ->
            if (error != null || value == null) return@rpc toast(error ?: "无法读取模型列表")
            val choices = mutableListOf<ModelChoice>()
            val groups = value.optJSONArray("groups") ?: JSONArray()
            for (i in 0 until groups.length()) {
                val group = groups.optJSONObject(i) ?: continue
                val provider = group.optString("id")
                val models = group.optJSONArray("models") ?: continue
                for (j in 0 until models.length()) {
                    val model = models.optJSONObject(j) ?: continue
                    val reasoning = model.optJSONObject("reasoning")
                    val effortsJson = reasoning?.optJSONArray("efforts")
                    val efforts = mutableListOf<String>()
                    if (effortsJson != null) for (k in 0 until effortsJson.length()) {
                        efforts += effortsJson.optJSONObject(k)?.optString("id").orEmpty()
                    }
                    choices += ModelChoice(
                        provider,
                        model.optString("id"),
                        model.optString("name").ifBlank { model.optString("id") },
                        efforts.filter { it.isNotBlank() },
                        reasoning?.optString("defaultEffort")?.takeIf { it.isNotBlank() }
                    )
                }
            }
            val labels = choices.map { "${it.name}   ·   ${it.provider}" }.toMutableList()
            labels += "＋ 自定义模型 ID…"
            AlertDialog.Builder(this)
                .setTitle("选择 Harness 模型")
                .setItems(labels.toTypedArray()) { _, which ->
                    if (which == choices.size) showCustomModelDialog() else showEffortPicker(choices[which])
                }
                .setNegativeButton("取消", null)
                .show()
        }
    }

    private fun showEffortPicker(choice: ModelChoice) {
        val efforts = if (choice.efforts.isEmpty()) listOf("off", "high", "max") else choice.efforts
        val labels = efforts.map { effortName(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(choice.name)
            .setMessage("选择思考强度（作用于当前 Harness 会话）")
            .setItems(labels) { _, which -> selectModel(choice.provider, choice.id, efforts[which]) }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showCustomModelDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), 0)
        }
        val provider = field("Provider", currentProvider.ifBlank { "deepseek-official" })
        val model = field("模型 ID", currentModel)
        val effort = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("off", "high", "max"))
            setSelection(arrayOf("off", "high", "max").indexOf(currentEffort).coerceAtLeast(1))
        }
        box.addView(formLabel("Provider（通常不用改）")); box.addView(provider)
        box.addView(formLabel("模型 ID（未列出的 ID Harness 也会原样传给 Provider）")); box.addView(model)
        box.addView(formLabel("思考强度")); box.addView(effort)
        AlertDialog.Builder(this)
            .setTitle("自定义模型")
            .setView(box)
            .setPositiveButton("应用") { _, _ ->
                val p = provider.text.toString().trim()
                val m = model.text.toString().trim()
                if (p.isNotBlank() && m.isNotBlank()) selectModel(p, m, effort.selectedItem.toString())
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun selectModel(provider: String, model: String, effort: String) {
        val sid = currentSessionId ?: return
        val payload = JSONObject()
            .put("sessionId", sid)
            .put("provider", provider)
            .put("model", model)
            .put("reasoningEffort", effort)
        client.rpc("session.selectModel", payload) { _, value, error ->
            if (error != null) return@rpc toast("模型切换失败：$error")
            currentProvider = provider; currentModel = model; currentEffort = effort
            val selected = value?.optJSONObject("selected")
            currentProvider = selected?.optString("provider", provider) ?: provider
            currentModel = selected?.optString("model", model) ?: model
            currentEffort = selected?.optString("reasoningEffort", effort) ?: effort
            refreshModelChip()
            updateTelemetryUi()
            toast("已切换：$currentModel · ${effortName(currentEffort)}")
        }
    }

    private fun effortName(id: String): String = when (id.lowercase()) {
        "off" -> "关闭思考"
        "max" -> "Max"
        "high" -> "High"
        else -> id
    }

    private fun resetTelemetry() {
        uncachedInputTokens = 0
        cacheReadTokens = 0
        cacheWriteTokens = 0
        outputTokens = 0
        pressureTokens = null
        projectedTokens = null
        contextWindow = null
        systemTokens = 0
        toolsTokens = 0
        messageTokens = 0
        projectionSeqs.clear()
        updateTelemetryUi()
    }

    private fun applyProjectionBlock(sessionId: String, block: JSONObject?) {
        if (block == null || sessionId != currentSessionId) return
        val seq = block.optLong("asOfSeq", -1L)
        val values = block.optJSONObject("values") ?: return
        values.keys().forEach { key -> applyProjectionValue(sessionId, key, values.opt(key), seq) }
    }

    private fun applyProjectionValue(sessionId: String, key: String, rawValue: Any?, seq: Long) {
        if (key == "title") {
            val title = when (rawValue) {
                null, JSONObject.NULL -> null
                else -> rawValue.toString().takeIf { it.isNotBlank() }
            }
            sessions.firstOrNull { it.sessionId == sessionId }?.title = title
            if (sessionId == currentSessionId && !title.isNullOrBlank()) sessionLabel.text = title
            if (sidebarOpen) renderSidebarSessions()
            return
        }
        if (sessionId != currentSessionId) return
        val previous = projectionSeqs[key] ?: Long.MIN_VALUE
        if (seq >= 0 && seq < previous) return
        if (seq >= 0) projectionSeqs[key] = seq
        val value = rawValue as? JSONObject ?: return
        when (key) {
            "tokenUsage" -> {
                uncachedInputTokens = value.optLong("uncachedInputTokens", 0L)
                outputTokens = value.optLong("outputTokens", 0L)
                cacheReadTokens = value.optLong("cacheReadTokens", 0L)
                cacheWriteTokens = value.optLong("cacheWriteTokens", 0L)
            }
            "contextPressure" -> {
                pressureTokens = value.longOrNull("pressureTokens")
                projectedTokens = value.longOrNull("projectedTokens")
                contextWindow = value.longOrNull("contextWindow")
            }
            "contextBreakdown" -> {
                systemTokens = value.optLong("systemTokens", 0L)
                toolsTokens = value.optLong("toolsTokens", 0L)
                messageTokens = value.optLong("messageTokens", 0L)
            }
            else -> return
        }
        updateTelemetryUi()
    }

    private fun JSONObject.longOrNull(key: String): Long? = if (has(key) && !isNull(key)) optLong(key) else null

    private data class PricePlan(val currency: String, val cacheHitPerM: Double, val missPerM: Double, val outputPerM: Double, val label: String)

    private fun selectedPricePlan(): PricePlan? {
        val auto = prefs.getBoolean("auto_official_pricing", true)
        val upstream = prefs.getString("upstream_base_url", "https://api.deepseek.com").orEmpty().trimEnd('/')
        if (auto && currentProvider == "deepseek-official" && upstream == "https://api.deepseek.com") {
            return when (currentModel.lowercase()) {
                "deepseek-v4-flash" -> PricePlan("¥", 0.02, 1.0, 2.0, "DeepSeek V4 Flash 官方价")
                "deepseek-v4-pro" -> PricePlan("¥", 0.025, 3.0, 6.0, "DeepSeek V4 Pro 官方价")
                else -> null
            }
        }
        val hit = prefs.getString("custom_price_hit", "")?.toDoubleOrNull()
        val miss = prefs.getString("custom_price_miss", "")?.toDoubleOrNull()
        val out = prefs.getString("custom_price_output", "")?.toDoubleOrNull()
        if (hit == null || miss == null || out == null) return null
        return PricePlan(prefs.getString("custom_price_currency", "¥").orEmpty().ifBlank { "¥" }, hit, miss, out, "自定义价格")
    }

    private fun estimatedCost(): Pair<Double, PricePlan>? {
        val plan = selectedPricePlan() ?: return null
        val cost = (cacheReadTokens * plan.cacheHitPerM +
            (uncachedInputTokens + cacheWriteTokens) * plan.missPerM +
            outputTokens * plan.outputPerM) / 1_000_000.0
        return cost to plan
    }

    private fun updateTelemetryUi() {
        if (!::statsStrip.isInitialized) return
        val used = projectedTokens ?: pressureTokens
        val contextText = if (used != null && contextWindow != null && contextWindow!! > 0) {
            val remaining = (contextWindow!! - used).coerceAtLeast(0L)
            "上下文 ${formatTokens(used)}/${formatTokens(contextWindow!!)} · 剩${formatTokens(remaining)}"
        } else "上下文 —"
        val billedInput = uncachedInputTokens + cacheReadTokens + cacheWriteTokens
        val tokenText = if (billedInput > 0 || outputTokens > 0) "入${formatTokens(billedInput)} 出${formatTokens(outputTokens)}" else "Token —"
        val cacheText = if (billedInput > 0) "缓存 ${Math.round(cacheReadTokens * 100.0 / billedInput)}%" else "缓存 —"
        val cost = estimatedCost()
        val costText = if (cost == null) "费用 —" else "≈${formatMoney(cost.first, cost.second.currency)}"
        statsStrip.text = "$contextText  |  $tokenText  |  $cacheText  |  $costText"
    }

    private fun formatTokens(n: Long): String = when {
        n < 1_000L -> n.toString()
        n < 1_000_000L -> String.format(Locale.US, if (n < 100_000) "%.1fK" else "%.0fK", n / 1_000.0)
        else -> String.format(Locale.US, if (n < 100_000_000) "%.2fM" else "%.1fM", n / 1_000_000.0)
    }

    private fun formatMoney(value: Double, currency: String): String = when {
        value < 0.01 -> "$currency${String.format(Locale.US, "%.4f", value)}"
        value < 1 -> "$currency${String.format(Locale.US, "%.3f", value)}"
        else -> "$currency${String.format(Locale.US, "%.2f", value)}"
    }

    private fun showTelemetryDetails() {
        val billedInput = uncachedInputTokens + cacheReadTokens + cacheWriteTokens
        val used = projectedTokens ?: pressureTokens
        val remaining = if (used != null && contextWindow != null) (contextWindow!! - used).coerceAtLeast(0L) else null
        val cachePercent = if (billedInput > 0) Math.round(cacheReadTokens * 100.0 / billedInput) else null
        val cost = estimatedCost()
        val text = buildString {
            append("上下文\n")
            if (used != null && contextWindow != null) {
                append("已占用/预计：${formatTokens(used)} / ${formatTokens(contextWindow!!)}\n")
                append("剩余：${formatTokens(remaining ?: 0)}")
            } else append("Harness 尚未返回上下文压力数据")
            append("\n\nToken（本会话累计）\n")
            append("未缓存输入：${formatTokens(uncachedInputTokens)}\n")
            append("缓存命中输入：${formatTokens(cacheReadTokens)}\n")
            append("缓存写入：${formatTokens(cacheWriteTokens)}\n")
            append("输出：${formatTokens(outputTokens)}")
            append("\n\n缓存命中率：${cachePercent?.let { "$it%" } ?: "—"}")
            if (systemTokens + toolsTokens + messageTokens > 0) {
                append("\n\n下次请求上下文构成（Harness 启发式估算）\n")
                append("系统提示：${formatTokens(systemTokens)} · 工具：${formatTokens(toolsTokens)} · 消息：${formatTokens(messageTokens)}")
            }
            append("\n\n费用：")
            if (cost != null) {
                append("≈${formatMoney(cost.first, cost.second.currency)}\n")
                append("计价：${cost.second.label}")
            } else append("—（当前模型/中转未配置价格）")
            append("\n\n说明：上下文占用来自 Harness 的 contextPressure 投影，是参考值；Token/缓存计数来自 Provider usage。费用由 App 按单价估算，不是余额账单；中途换模型、第三方中转加价会让估算产生偏差。")
        }
        AlertDialog.Builder(this)
            .setTitle("会话用量")
            .setMessage(text)
            .setPositiveButton("知道了", null)
            .show()
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(6), dp(18), dp(18))
        }
        val scroll = ScrollView(this).apply { addView(box) }

        box.addView(sectionTitle("Harness 运行方式"))
        val embeddedRuntime = Switch(this).apply {
            text = "使用 App 内置 Harness（推荐，不需要 Termux）"
            isChecked = prefs.getBoolean("embedded_runtime", true)
            setTextColor(Color.rgb(31, 48, 69)); textSize = 14f
        }
        val runtimeState = TextView(this).apply {
            text = if (embeddedRuntime.isChecked) "内置运行时：${EmbeddedHarnessRuntime.detail.ifBlank { "等待启动" }}" else "外部 Harness 模式"
            textSize = 11.5f
            setTextColor(Color.rgb(92, 108, 126))
            setPadding(0, dp(3), 0, dp(5))
        }
        val harnessUrl = field("外部 Harness 地址", prefs.getString("harness_url", "http://127.0.0.1:3080") ?: "http://127.0.0.1:3080")
        harnessUrl.isEnabled = !embeddedRuntime.isChecked
        embeddedRuntime.setOnCheckedChangeListener { _, checked ->
            harnessUrl.isEnabled = !checked
            runtimeState.text = if (checked) "内置运行时：保存后自动使用 App 内 Harness" else "外部 Harness 模式：将连接下面地址"
        }
        box.addView(embeddedRuntime); box.addView(runtimeState)
        box.addView(formLabel("只有关闭内置 Harness 时才使用这个地址")); box.addView(harnessUrl)

        box.addView(sectionTitle("DeepSeek Provider"))
        val keyState = TextView(this).apply {
            text = "正在读取密钥状态…"
            textSize = 12f
            setTextColor(Color.rgb(92, 108, 126))
            setPadding(0, dp(3), 0, dp(6))
        }
        val apiKey = field("新的 API Key（留空不修改）", "").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val upstreamUrl = field("DeepSeek API / 中转地址", prefs.getString("upstream_base_url", "https://api.deepseek.com") ?: "https://api.deepseek.com")
        val maxTokens = field("默认最大输出 tokens", prefs.getString("max_tokens", "256000") ?: "256000").apply {
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        box.addView(keyState); box.addView(apiKey)
        box.addView(formLabel("真实上游 API Base URL（启用采样代理后，Harness 会指向本机 3081）")); box.addView(upstreamUrl)
        box.addView(formLabel("DeepSeek Harness 默认最大输出 tokens")); box.addView(maxTokens)
        box.addView(TextView(this).apply {
            text = "密钥不会从 Harness 读回明文；这里只能写入新值。内置模式会保存到 App 私有 Harness 凭据文件；若外部 Harness 的密钥来自只读环境变量，则这里只显示为只读。"
            textSize = 11.5f
            setTextColor(Color.rgb(105, 117, 132))
            setPadding(0, dp(4), 0, dp(6))
        })

        box.addView(sectionTitle("高级采样参数"))
        val proxyEnabled = Switch(this).apply {
            text = "启用本机高级采样代理（内置模式已随 App 提供）"
            isChecked = prefs.getBoolean("sampling_proxy_enabled", false)
            setTextColor(Color.rgb(31, 48, 69)); textSize = 14f
        }
        box.addView(proxyEnabled)

        val tempEnabled = Switch(this).apply {
            text = "覆盖 temperature"
            isChecked = prefs.getBoolean("temperature_enabled", false)
            setTextColor(Color.rgb(31, 48, 69)); textSize = 13.5f
        }
        val tempLabel = formLabel("Temperature：${prefs.getInt("temperature_tenths", 10) / 10.0}")
        val tempSeek = SeekBar(this).apply {
            max = 20
            progress = prefs.getInt("temperature_tenths", 10).coerceIn(0, 20)
            setOnSeekBarChangeListener(simpleSeek { p -> tempLabel.text = "Temperature：${p / 10.0}" })
        }
        box.addView(tempEnabled); box.addView(tempLabel); box.addView(tempSeek)

        val topPEnabled = Switch(this).apply {
            text = "覆盖 top_p"
            isChecked = prefs.getBoolean("top_p_enabled", false)
            setTextColor(Color.rgb(31, 48, 69)); textSize = 13.5f
        }
        val topPLabel = formLabel("Top-p：${String.format(Locale.US, "%.2f", prefs.getInt("top_p_twentieths", 20) / 20.0)}")
        val topPSeek = SeekBar(this).apply {
            max = 20
            progress = prefs.getInt("top_p_twentieths", 20).coerceIn(0, 20)
            setOnSeekBarChangeListener(simpleSeek { p -> topPLabel.text = "Top-p：${String.format(Locale.US, "%.2f", p / 20.0)}" })
        }
        box.addView(topPEnabled); box.addView(topPLabel); box.addView(topPSeek)
        box.addView(TextView(this).apply {
            text = "重要：DeepSeek V4 在 High / Max 思考模式下会忽略 temperature 和 top_p。只有把思考强度切到 Off（非思考）时这两个参数才真正生效。v0.5 内置 Harness 已同时内置 3081 采样代理，不需要 Termux。"
            textSize = 11.5f
            setTextColor(Color.rgb(155, 91, 55))
            setPadding(0, dp(5), 0, dp(6))
        })

        box.addView(sectionTitle("Token 费用估算"))
        val autoPrice = Switch(this).apply {
            text = "官方 DeepSeek V4 使用内置最新人民币单价"
            isChecked = prefs.getBoolean("auto_official_pricing", true)
            setTextColor(Color.rgb(31, 48, 69)); textSize = 13.5f
        }
        box.addView(autoPrice)
        val currency = field("货币符号", prefs.getString("custom_price_currency", "¥") ?: "¥")
        val hitPrice = field("缓存命中 / 1M tokens", prefs.getString("custom_price_hit", "") ?: "").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val missPrice = field("缓存未命中 / 1M tokens", prefs.getString("custom_price_miss", "") ?: "").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val outputPrice = field("输出 / 1M tokens", prefs.getString("custom_price_output", "") ?: "").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        box.addView(formLabel("自定义模型 / 中转站价格（关闭自动官方价时使用）")); box.addView(currency)
        box.addView(hitPrice); box.addView(missPrice); box.addView(outputPrice)
        box.addView(TextView(this).apply {
            text = "费用只做估算，不读取余额或账单。若一个会话中途换过模型，汇总 Token × 当前价格也可能有偏差。"
            textSize = 11.5f; setTextColor(Color.rgb(105, 117, 132)); setPadding(0, dp(4), 0, dp(6))
        })

        box.addView(sectionTitle("外观与可读性"))
        val skin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("蓝色幻想 · 鲸鱼娘", "极简浅色", "深海夜色"))
            setSelection(when (prefs.getString("skin", "blue")) { "plain" -> 1; "dark" -> 2; else -> 0 })
        }
        box.addView(formLabel("背景皮肤")); box.addView(skin)

        val fontLabel = formLabel("正文字号：${fontScalePercent()}%")
        val fontSeek = SeekBar(this).apply {
            max = 8
            progress = (((prefs.getFloat("font_scale", 1f) - 0.9f) / 0.05f).toInt()).coerceIn(0, 8)
            setOnSeekBarChangeListener(simpleSeek { p -> fontLabel.text = "正文字号：${((0.9f + p * 0.05f) * 100).toInt()}%" })
        }
        box.addView(fontLabel); box.addView(fontSeek)

        val wallLabel = formLabel("壁纸可见度：${prefs.getInt("wallpaper_visibility", 58)}%")
        val wallSeek = SeekBar(this).apply {
            max = 100; progress = prefs.getInt("wallpaper_visibility", 58)
            setOnSeekBarChangeListener(simpleSeek { p -> wallLabel.text = "壁纸可见度：$p%" })
        }
        box.addView(wallLabel); box.addView(wallSeek)

        val contrast = Switch(this).apply {
            text = "高对比文字卡片（壁纸上更清楚）"
            isChecked = prefs.getBoolean("high_contrast", true)
            setTextColor(Color.rgb(31, 48, 69)); textSize = 14f
            setPadding(0, dp(6), 0, dp(2))
        }
        box.addView(contrast)

        var keyWritable = false
        var keyKnown = false
        client.rpc("credentials.describe", JSONObject().put("refs", JSONArray().put("DEEPSEEK_API_KEY"))) { _, value, error ->
            if (error != null) {
                keyState.text = "密钥状态：读取失败（$error）"
            } else {
                val view = value?.optJSONObject("credentials")?.optJSONObject("DEEPSEEK_API_KEY")
                val configured = view?.optBoolean("configured") == true
                keyWritable = view?.optBoolean("writable") == true
                keyKnown = true
                val source = view?.optString("source")?.takeIf { it.isNotBlank() } ?: "未设置"
                keyState.text = when {
                    configured && keyWritable -> "密钥：已配置 · 来源 $source · 可在 App 中更新"
                    configured -> "密钥：已配置 · 来源 $source · 当前只读（继续使用现有值即可）"
                    else -> "密钥：未配置${if (keyWritable) " · 可在 App 中填写" else ""}"
                }
            }
        }
        client.rpc("settings.describe", JSONObject()) { _, value, _ ->
            val arr = value?.optJSONArray("namespaces") ?: return@rpc
            for (i in 0 until arr.length()) {
                val ns = arr.optJSONObject(i) ?: continue
                if (ns.optString("ns") == "llm-deepseek") {
                    val v = ns.optJSONObject("value")
                    val url = v?.optString("baseURL")
                    val storedUpstream = prefs.getString("upstream_base_url", null)
                    if (!url.isNullOrBlank() && url != "http://127.0.0.1:3081") {
                        upstreamUrl.setText(url)
                    } else if (!storedUpstream.isNullOrBlank()) upstreamUrl.setText(storedUpstream)
                    val mt = v?.optLong("maxTokens", -1L) ?: -1L
                    if (mt > 0) maxTokens.setText(mt.toString())
                    break
                }
            }
        }
        samplingProxy.getConfig { cfg, _ ->
            if (cfg != null) {
                val u = cfg.optString("upstreamBaseURL")
                if (u.isNotBlank()) upstreamUrl.setText(u)
                if (!cfg.isNull("temperature")) {
                    val t = cfg.optDouble("temperature", 1.0).coerceIn(0.0, 2.0)
                    tempSeek.progress = Math.round(t * 10).toInt()
                    tempEnabled.isChecked = true
                }
                if (!cfg.isNull("topP")) {
                    val t = cfg.optDouble("topP", 1.0).coerceIn(0.0, 1.0)
                    topPSeek.progress = Math.round(t * 20).toInt()
                    topPEnabled.isChecked = true
                }
            }
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Harness Chat v0.5 设置")
            .setView(scroll)
            .setPositiveButton("保存", null)
            .setNegativeButton("取消", null)
            .setNeutralButton("皮肤来源") { _, _ -> showSkinCredits() }
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val oldHarness = prefs.getString("harness_url", "http://127.0.0.1:3080") ?: "http://127.0.0.1:3080"
                val oldEmbedded = useEmbeddedRuntime()
                val newHarness = harnessUrl.text.toString().trim().trimEnd('/').ifBlank { "http://127.0.0.1:3080" }
                val upstream = upstreamUrl.text.toString().trim().trimEnd('/').ifBlank { "https://api.deepseek.com" }
                val maxOut = maxTokens.text.toString().trim().toLongOrNull()?.coerceAtLeast(1L) ?: 256000L
                val skinId = when (skin.selectedItemPosition) { 1 -> "plain"; 2 -> "dark"; else -> "blue" }
                prefs.edit()
                    .putString("harness_url", newHarness)
                    .putBoolean("embedded_runtime", embeddedRuntime.isChecked)
                    .putString("upstream_base_url", upstream)
                    .putString("max_tokens", maxOut.toString())
                    .putBoolean("sampling_proxy_enabled", proxyEnabled.isChecked)
                    .putBoolean("temperature_enabled", tempEnabled.isChecked)
                    .putInt("temperature_tenths", tempSeek.progress)
                    .putBoolean("top_p_enabled", topPEnabled.isChecked)
                    .putInt("top_p_twentieths", topPSeek.progress)
                    .putBoolean("auto_official_pricing", autoPrice.isChecked)
                    .putString("custom_price_currency", currency.text.toString().trim().ifBlank { "¥" })
                    .putString("custom_price_hit", hitPrice.text.toString().trim())
                    .putString("custom_price_miss", missPrice.text.toString().trim())
                    .putString("custom_price_output", outputPrice.text.toString().trim())
                    .putString("skin", skinId)
                    .putFloat("font_scale", 0.9f + fontSeek.progress * 0.05f)
                    .putInt("wallpaper_visibility", wallSeek.progress)
                    .putBoolean("high_contrast", contrast.isChecked)
                    .apply()
                applyAppearance()
                updateTelemetryUi()

                val typedKey = apiKey.text.toString().trim()
                if (typedKey.isNotBlank()) {
                    when {
                        !keyKnown -> toast("还没读到密钥状态，请稍后再打开设置")
                        !keyWritable -> toast("当前密钥来自只读宿主环境，Harness 不允许 App 覆盖；现有密钥仍会正常使用")
                        else -> client.rpc("credentials.set", JSONObject().put("ref", "DEEPSEEK_API_KEY").put("value", typedKey)) { _, _, error ->
                            if (error != null) toast("密钥保存失败：$error") else toast("API Key 已写入 Harness")
                        }
                    }
                }

                saveDeepSeekRuntimeSettings(
                    upstream = upstream,
                    proxyEnabled = proxyEnabled.isChecked,
                    temperature = if (tempEnabled.isChecked) tempSeek.progress / 10.0 else null,
                    topP = if (topPEnabled.isChecked) topPSeek.progress / 20.0 else null,
                    maxTokens = maxOut
                )
                val modeChanged = oldEmbedded != embeddedRuntime.isChecked
                if (modeChanged || (!embeddedRuntime.isChecked && newHarness != oldHarness)) {
                    if (embeddedRuntime.isChecked) {
                        status.text = "正在启动内置 Harness…"
                        EmbeddedHarnessRuntime.start(this) { _, detail -> if (!connected) status.text = detail }
                    } else {
                        status.text = "正在连接外部 Harness…"
                    }
                    connectClient()
                    refreshSessions(openPreferred = true)
                }
                adapter.notifyDataSetChanged()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun saveDeepSeekRuntimeSettings(upstream: String, proxyEnabled: Boolean, temperature: Double?, topP: Double?, maxTokens: Long) {
        fun updateHarnessBase(base: String) {
            val patch = JSONObject().put("baseURL", base).put("maxTokens", maxTokens)
            client.rpc("settings.update", JSONObject().put("ns", "llm-deepseek").put("patch", patch)) { _, _, error ->
                if (error != null) toast("DeepSeek 设置保存失败：$error")
                else toast(if (proxyEnabled) "采样代理已启用；Off 模式下参数会生效" else "DeepSeek 设置已保存")
            }
        }
        if (!proxyEnabled) {
            updateHarnessBase(upstream)
            return
        }
        val config = JSONObject()
            .put("upstreamBaseURL", upstream)
            .put("temperature", temperature ?: JSONObject.NULL)
            .put("topP", topP ?: JSONObject.NULL)
        samplingProxy.setConfig(config) { _, error ->
            if (error != null) {
                toast("采样代理还没就绪，未改 Harness Base URL。内置模式请稍等 Harness 完成启动后重试。\n$error")
            } else updateHarnessBase("http://127.0.0.1:3081")
        }
    }

    private fun showSkinCredits() {
        AlertDialog.Builder(this)
            .setTitle("蓝色幻想 · 壁纸来源")
            .setMessage(
                "背景来自社区 dsh-web-ui 的 Blue Fantasy 皮肤。该皮肤说明其鲸鱼背景源自 DreamSkin『DeepSeek-鲸鱼娘』，原作者 powerdog996，背景艺术按 MIT 许可；社区移植包由 zhu1090093659 维护并采用 BSD-3-Clause。\\n\\nApp 构建时从公开仓库提取原始 1920×1079 压缩背景，并附带第三方许可说明。"
            )
            .setPositiveButton("知道了", null)
            .show()
    }

    private fun field(hint: String, value: String): EditText = EditText(this).apply {
        this.hint = hint
        setText(value)
        setTextColor(Color.rgb(24, 38, 56))
        setHintTextColor(Color.rgb(137, 149, 163))
        textSize = 14f
        setPadding(dp(12), dp(9), dp(12), dp(9))
        background = rounded(Color.rgb(246, 249, 253), 12, Color.rgb(207, 218, 232), 1)
    }

    private fun formLabel(textValue: String): TextView = TextView(this).apply {
        text = textValue
        setTextColor(Color.rgb(65, 82, 103))
        textSize = 12f
        setPadding(0, dp(8), 0, dp(3))
    }

    private fun sectionTitle(textValue: String): TextView = TextView(this).apply {
        text = textValue
        setTextColor(Color.rgb(24, 52, 82))
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
        textSize = 15.5f
        setPadding(0, dp(13), 0, dp(3))
    }

    private fun simpleSeek(onProgress: (Int) -> Unit): SeekBar.OnSeekBarChangeListener = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = onProgress(progress)
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun fontScalePercent(): Int = (prefs.getFloat("font_scale", 1f) * 100).toInt()

    private fun appearance(): AppearanceState {
        val skin = prefs.getString("skin", "blue") ?: "blue"
        return AppearanceState(
            skin = skin,
            fontScale = prefs.getFloat("font_scale", 1f).coerceIn(0.9f, 1.3f),
            highContrast = prefs.getBoolean("high_contrast", true),
            dark = skin == "dark"
        )
    }

    private fun applyAppearance() {
        val a = appearance()
        val visibility = prefs.getInt("wallpaper_visibility", 58).coerceIn(0, 100)
        val wallpaperId = resources.getIdentifier("blue_fantasy_wallpaper", "drawable", packageName)
        if ((a.skin == "blue" || a.skin == "dark") && wallpaperId != 0) {
            wallpaper.setImageResource(wallpaperId)
            wallpaper.visibility = View.VISIBLE
            wallpaper.alpha = (0.45f + visibility / 100f * 0.55f).coerceIn(0f, 1f)
        } else {
            wallpaper.setImageDrawable(null)
            wallpaper.visibility = View.GONE
        }
        when (a.skin) {
            "dark" -> {
                rootFrame.setBackgroundColor(Color.rgb(13, 23, 41))
                val alpha = (205 - visibility * 0.55).toInt().coerceIn(130, 220)
                veil.setBackgroundColor(Color.argb(alpha, 10, 23, 48))
                topBar.setBackgroundColor(Color.argb(218, 14, 31, 54))
                headerTitle.setTextColor(Color.rgb(239, 245, 252))
                for (i in 1 until topBar.childCount) (topBar.getChildAt(i) as? TextView)?.setTextColor(Color.rgb(221, 234, 248))
                composerCard.background = rounded(Color.argb(242, 23, 40, 63), 22, Color.argb(100, 120, 151, 190), 1)
                input.setTextColor(Color.rgb(238, 245, 252)); input.setHintTextColor(Color.rgb(154, 172, 192))
                modelChip.setTextColor(Color.rgb(218, 232, 248)); modelChip.background = rounded(Color.argb(100, 73, 105, 148), 14)
                WindowCompat.getInsetsController(window, rootFrame).apply { isAppearanceLightStatusBars = false; isAppearanceLightNavigationBars = false }
            }
            "plain" -> {
                rootFrame.setBackgroundColor(Color.rgb(246, 249, 253))
                veil.setBackgroundColor(Color.TRANSPARENT)
                topBar.setBackgroundColor(Color.argb(245, 255, 255, 255))
                headerTitle.setTextColor(Color.rgb(20, 36, 58))
                for (i in 1 until topBar.childCount) (topBar.getChildAt(i) as? TextView)?.setTextColor(Color.rgb(31, 52, 78))
                composerCard.background = rounded(Color.rgb(255, 255, 255), 22, Color.rgb(205, 216, 231), 1)
                input.setTextColor(Color.rgb(21, 32, 47)); input.setHintTextColor(Color.rgb(132, 145, 161))
                modelChip.setTextColor(Color.rgb(49, 69, 96)); modelChip.background = rounded(Color.rgb(236, 243, 251), 14)
                WindowCompat.getInsetsController(window, rootFrame).apply { isAppearanceLightStatusBars = true; isAppearanceLightNavigationBars = true }
            }
            else -> {
                rootFrame.setBackgroundColor(Color.rgb(238, 247, 253))
                val alpha = (218 - visibility * 1.15).toInt().coerceIn(92, 218)
                veil.setBackgroundColor(Color.argb(alpha, 247, 251, 255))
                topBar.setBackgroundColor(Color.argb(208, 248, 252, 255))
                headerTitle.setTextColor(Color.rgb(20, 36, 58))
                for (i in 1 until topBar.childCount) (topBar.getChildAt(i) as? TextView)?.setTextColor(Color.rgb(31, 52, 78))
                composerCard.background = rounded(Color.argb(240, 255, 255, 255), 22, Color.argb(100, 143, 165, 194), 1)
                input.setTextColor(Color.rgb(21, 32, 47)); input.setHintTextColor(Color.rgb(132, 145, 161))
                modelChip.setTextColor(Color.rgb(49, 69, 96)); modelChip.background = rounded(Color.argb(135, 230, 239, 250), 14)
                WindowCompat.getInsetsController(window, rootFrame).apply { isAppearanceLightStatusBars = true; isAppearanceLightNavigationBars = true }
            }
        }
        statsStrip.setTextColor(if (a.dark) Color.rgb(174, 194, 216) else Color.rgb(99, 115, 134))
        sidebarTitle.setTextColor(if (a.dark) Color.rgb(239, 246, 253) else Color.rgb(27, 48, 72))
        sidebarPanel.setBackgroundColor(if (a.dark) Color.rgb(20, 35, 55) else Color.argb(250, 249, 252, 255))
        sidebarSearch.setTextColor(if (a.dark) Color.rgb(238, 245, 252) else Color.rgb(27, 42, 61))
        sidebarSearch.setHintTextColor(if (a.dark) Color.rgb(153, 173, 195) else Color.rgb(129, 143, 160))
        sidebarSearch.background = rounded(
            if (a.dark) Color.rgb(31, 50, 73) else Color.argb(235, 246, 250, 254), 14,
            if (a.dark) Color.rgb(78, 105, 135) else Color.rgb(205, 217, 231), 1
        )
        if (sidebarOpen) renderSidebarSessions()
        adapter.notifyDataSetChanged()
    }

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int? = null, strokeDp: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeColor != null && strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

    private fun isAppendOrigin(event: JSONObject): Boolean {
        val op = event.opt("surfaceOp")
        return op == null || op == JSONObject.NULL || op == "append"
    }

    private fun extractText(blocks: JSONArray?): String = extractBlocks(blocks, "text")
    private fun extractReasoning(blocks: JSONArray?): String = extractBlocks(blocks, "reasoning")

    private fun extractBlocks(blocks: JSONArray?, type: String): String {
        if (blocks == null) return ""
        val out = StringBuilder()
        for (i in 0 until blocks.length()) {
            val b = blocks.optJSONObject(i) ?: continue
            if (b.optString("type") != type) continue
            if (out.isNotEmpty()) out.append("\n\n")
            out.append(b.optString("text"))
        }
        return out.toString()
    }

    private fun scrollBottom() {
        list.post {
            if (messages.isNotEmpty()) list.scrollToPosition(messages.lastIndex)
        }
    }

    private fun scrollTop() {
        list.post {
            if (messages.isNotEmpty()) {
                (list.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(0, 0)
            }
        }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()


    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
