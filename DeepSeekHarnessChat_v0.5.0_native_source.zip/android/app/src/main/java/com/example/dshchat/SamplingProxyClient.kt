package com.example.dshchat

import android.os.Handler
import android.os.Looper
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Talks only to the loopback sampling helper. In v0.5 embedded mode it runs inside the same
 * in-process Node runtime as Harness; external mode may provide a compatible helper separately.
 * The helper never stores or exposes API keys; Authorization still comes from Harness.
 */
class SamplingProxyClient(
    private val baseUrl: String = "http://127.0.0.1:3081"
) {
    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .connectTimeout(1200, TimeUnit.MILLISECONDS)
        .readTimeout(2500, TimeUnit.MILLISECONDS)
        .writeTimeout(2500, TimeUnit.MILLISECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    fun getConfig(callback: (JSONObject?, String?) -> Unit) {
        val req = Request.Builder().url("$baseUrl/__dsh_mobile/config").get().build()
        http.newCall(req).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {
                main.post { callback(null, e.message ?: "采样代理未运行") }
            }
            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                response.use {
                    val text = it.body?.string().orEmpty()
                    if (!it.isSuccessful) main.post { callback(null, "HTTP ${it.code}: $text") }
                    else main.post {
                        runCatching { JSONObject(text) }
                            .onSuccess { obj -> callback(obj, null) }
                            .onFailure { e -> callback(null, e.message ?: "配置响应无法解析") }
                    }
                }
            }
        })
    }

    fun setConfig(config: JSONObject, callback: (JSONObject?, String?) -> Unit) {
        val req = Request.Builder()
            .url("$baseUrl/__dsh_mobile/config")
            .post(config.toString().toRequestBody(jsonType))
            .build()
        http.newCall(req).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {
                main.post { callback(null, e.message ?: "采样代理未运行") }
            }
            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                response.use {
                    val text = it.body?.string().orEmpty()
                    if (!it.isSuccessful) main.post { callback(null, "HTTP ${it.code}: $text") }
                    else main.post {
                        runCatching { JSONObject(text) }
                            .onSuccess { obj -> callback(obj, null) }
                            .onFailure { e -> callback(null, e.message ?: "配置响应无法解析") }
                    }
                }
            }
        })
    }
}
