package com.example.dshchat

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

/**
 * Embedded Node.js host for the v0.5 Android experiment.
 *
 * Node is linked into the APK as libnode.so and launched through JNI. Only JS/data are
 * extracted into the app-private files directory; no executable is copied to writable
 * storage (Android 10+ forbids that pattern).
 */
object EmbeddedHarnessRuntime {
    enum class State { IDLE, PREPARING, STARTING, RUNNING, FAILED, EXITED }

    @Volatile var state: State = State.IDLE
        private set
    @Volatile var detail: String = ""
        private set

    private val main = Handler(Looper.getMainLooper())
    private var librariesLoaded = false
    private var started = false

    private external fun startNodeWithArguments(arguments: Array<String>): Int

    @Synchronized
    fun start(context: Context, onState: (State, String) -> Unit = { _, _ -> }) {
        if (started) {
            onState(state, detail)
            return
        }
        started = true
        update(State.PREPARING, "正在准备内置 Harness…", onState)

        Thread({
            try {
                loadLibraries()
                val projectDir = prepareProject(context.applicationContext)
                val entry = File(projectDir, "main.mjs")
                if (!entry.isFile) error("内置 Harness 启动文件缺失：${entry.absolutePath}")

                update(State.STARTING, "正在启动内置 Node.js / Harness…", onState)
                // main.mjs receives app-private filesDir and owns DSH_HOME/workspace setup.
                val rc = startNodeWithArguments(arrayOf(
                    "node",
                    entry.absolutePath,
                    context.filesDir.absolutePath
                ))
                if (rc == 0) update(State.EXITED, "内置 Harness 已停止", onState)
                else update(State.FAILED, "内置 Harness 退出，代码 $rc", onState)
            } catch (t: Throwable) {
                Log.e("DSH-EMBEDDED", "embedded runtime failed", t)
                update(State.FAILED, t.message ?: t.javaClass.simpleName, onState)
            }
        }, "dsh-embedded-node").start()
    }

    private fun loadLibraries() {
        if (librariesLoaded) return
        // libnode must be present in the APK. dshbridge links against it and calls node::Start.
        System.loadLibrary("node")
        System.loadLibrary("dshbridge")
        librariesLoaded = true
    }

    private fun prepareProject(context: Context): File {
        val version = "0.5.0-node24"
        val prefs = context.getSharedPreferences("dsh_embedded_runtime", Context.MODE_PRIVATE)
        val root = File(context.filesDir, "embedded-nodejs-project")
        if (prefs.getString("asset_version", null) == version && File(root, "main.mjs").isFile) {
            return root
        }

        if (root.exists()) root.deleteRecursively()
        root.mkdirs()
        context.assets.open("nodejs-project.zip").use { input ->
            ZipInputStream(input.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val out = File(root, entry.name)
                    val canonicalRoot = root.canonicalPath + File.separator
                    val canonicalOut = out.canonicalPath
                    if (!canonicalOut.startsWith(canonicalRoot)) error("非法内置资源路径：${entry.name}")
                    if (entry.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { target -> zip.copyTo(target, 64 * 1024) }
                    }
                    zip.closeEntry()
                }
            }
        }
        prefs.edit().putString("asset_version", version).apply()
        return root
    }

    fun markServerReady() {
        state = State.RUNNING
        detail = "内置 Harness 已就绪"
    }

    private fun update(state: State, detail: String, callback: (State, String) -> Unit) {
        this.state = state
        this.detail = detail
        main.post { callback(state, detail) }
    }
}
